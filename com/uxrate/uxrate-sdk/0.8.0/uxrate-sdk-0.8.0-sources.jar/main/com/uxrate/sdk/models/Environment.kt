package com.uxrate.sdk.models

/**
 * Resolves the backend baseURL from the API key prefix.
 *
 * Keys issued by the dashboard carry an environment infix:
 *   `uxr_<hex>`        → production  (https://app.uxrate.com)
 *   `uxr_dev_<hex>`    → development (https://app-dev.uxrate.com)
 *   `uxr_loc_<hex>`    → local       (Android emulator -> 10.0.2.2:3000)
 *
 * The literal sentinel `"mock"` selects the in-memory mock service
 * (returns null here so the caller can branch).
 */
object BaseURLResolver {
    fun resolve(apiKey: String): String? = when {
        apiKey == "mock" -> null
        apiKey.startsWith("uxr_dev_") -> "https://app-dev.uxrate.com"
        apiKey.startsWith("uxr_loc_") -> "http://10.0.2.2:3000"
        else -> "https://app.uxrate.com"
    }

    fun isMock(apiKey: String): Boolean = apiKey == "mock"
}
