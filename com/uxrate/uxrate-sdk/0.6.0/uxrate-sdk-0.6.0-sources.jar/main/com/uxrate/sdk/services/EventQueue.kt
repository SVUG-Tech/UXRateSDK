package com.uxrate.sdk.services

import android.util.Log
import com.uxrate.sdk.UXRate
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Event item tracked by the SDK.
 * Serialized to JSON for backend submission.
 */
data class SdkEventItem(
    val type: String,
    val timestamp: String,
    val name: String? = null,
    val properties: Map<String, Any>? = null,
    val studyId: String? = null,
    val count: Int = 1
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("type", type)
            put("timestamp", timestamp)
            if (name != null) put("name", name)
            if (properties != null) {
                put("properties", JSONObject(properties))
            }
            if (studyId != null) put("studyId", studyId)
            put("count", count)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): SdkEventItem {
            val props = if (json.has("properties") && !json.isNull("properties")) {
                val propsJson = json.getJSONObject("properties")
                val map = mutableMapOf<String, Any>()
                propsJson.keys().forEach { key ->
                    map[key] = propsJson.get(key)
                }
                map
            } else null

            return SdkEventItem(
                type = json.getString("type"),
                timestamp = json.getString("timestamp"),
                name = if (json.has("name")) json.getString("name") else null,
                properties = props,
                studyId = if (json.has("studyId")) json.getString("studyId") else null,
                count = json.optInt("count", 1)
            )
        }

        fun nowTimestamp(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            return sdf.format(Date())
        }
    }
}

/**
 * SQLite-backed event queue. Events are persisted immediately on enqueue
 * (write-ahead) so they survive app crashes. Flush reads a batch from the
 * database, sends to the backend, then deletes confirmed rows.
 */
class EventQueue(
    private val service: SurveyService,
    private val storage: LocalStorage,
    private val participantId: String
) {
    companion object {
        private const val TAG = "UXRate"
        private const val FLUSH_THRESHOLD = 50
    }

    private val db: Database = storage.database
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * Persists an event to SQLite immediately. Auto-flushes when the threshold is reached.
     */
    fun enqueue(event: SdkEventItem) {
        val propsJson = event.properties?.let { JSONObject(it).toString() }

        db.exec("""
            INSERT INTO events (type, timestamp, name, properties, study_id, count)
            VALUES (?, ?, ?, ?, ?, ?)
        """,
            event.type,
            event.timestamp,
            event.name ?: "",
            propsJson ?: "",
            event.studyId ?: "",
            event.count
        )

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Event enqueued to SQLite: type=${event.type}, name=${event.name}")
        }

        // Auto-flush if we've accumulated enough events
        val pendingCount = db.scalarInt("SELECT COUNT(*) FROM events")
        if (pendingCount >= FLUSH_THRESHOLD) {
            flush()
        }
    }

    /**
     * Reads a batch of events from SQLite, sends to backend, deletes on success.
     * Events remain in SQLite on failure for retry on next flush.
     */
    fun flush() {
        val rows = db.queryRows(
            "SELECT id, type, timestamp, name, properties, study_id, count FROM events ORDER BY id LIMIT 50"
        )
        if (rows.isEmpty()) return

        val batch = mutableListOf<SdkEventItem>()
        val ids = mutableListOf<String>()

        for (row in rows) {
            val id = row["id"] ?: continue
            val type = row["type"] ?: continue
            val timestamp = row["timestamp"] ?: continue

            val props: Map<String, Any>? = row["properties"]?.let { pStr ->
                if (pStr.isNotEmpty()) {
                    try {
                        val json = JSONObject(pStr)
                        val map = mutableMapOf<String, Any>()
                        json.keys().forEach { key -> map[key] = json.get(key) }
                        map
                    } catch (_: Exception) { null }
                } else null
            }

            batch.add(SdkEventItem(
                type = type,
                timestamp = timestamp,
                name = row["name"]?.ifEmpty { null },
                properties = props,
                studyId = row["study_id"]?.ifEmpty { null },
                count = row["count"]?.toIntOrNull() ?: 1
            ))
            ids.add(id)
        }

        if (batch.isEmpty()) return

        scope.launch {
            try {
                service.sendEvents(participantId, batch)

                // Delete successfully sent events
                val placeholders = ids.joinToString(", ") { "?" }
                db.writableDatabase.execSQL(
                    "DELETE FROM events WHERE id IN ($placeholders)",
                    ids.toTypedArray()
                )

                if (UXRate.loggingEnabled) {
                    Log.d(TAG, "Flushed ${batch.size} events from SQLite to backend")
                }
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to flush events, will retry next flush: ${e.message}")
                }
                // Events remain in SQLite — no action needed
            }
        }
    }
}
