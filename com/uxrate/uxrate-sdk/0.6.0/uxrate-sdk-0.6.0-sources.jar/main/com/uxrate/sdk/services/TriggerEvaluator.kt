package com.uxrate.sdk.services

import com.uxrate.sdk.models.EventRule
import com.uxrate.sdk.models.SDKConfig
import com.uxrate.sdk.models.ScreenRule
import com.uxrate.sdk.models.SurveyConfig
import com.uxrate.sdk.models.Trigger
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Evaluates per-study triggers against the current screen and the in-memory
 * event counters.
 *
 * Pseudocode (from `TRIGGERS_SPEC.md` §2):
 *
 *     study matches if ANY trigger T:
 *         (T.screens empty OR some s in T.screens matches currentScreen)
 *       AND
 *         (T.events  empty OR
 *            T.eventLogic == "all" → every e in T.events: count(e) >= e.count
 *            T.eventLogic == "any" → at least one e satisfies)
 *
 * `count(e)` reads `sessionEventCount` or `onScreenEventCount[currentScreen]`
 * depending on `e.scope`.
 */
class TriggerEvaluator(private val storage: LocalStorage) {

    /** Map readers supplied by SurveyManager so the evaluator stays stateless
     *  and easily unit-testable. */
    fun interface CountSource {
        fun count(eventName: String, scope: String, screen: String): Int
    }

    /**
     * Returns ALL surveys that match the current context, ordered by descending
     * priority.
     */
    fun matchingSurveys(
        screen: String,
        config: SDKConfig,
        sessionCount: Int,
        countSource: CountSource
    ): List<SurveyConfig> {
        return config.surveys.filter { survey ->
            passesFrequency(survey, sessionCount) &&
                survey.triggers.any { evaluate(it, screen, countSource) }
        }.sortedByDescending { it.priority }
    }

    fun survey(
        screen: String,
        config: SDKConfig,
        sessionCount: Int,
        countSource: CountSource
    ): SurveyConfig? = matchingSurveys(screen, config, sessionCount, countSource).firstOrNull()

    // MARK: - Frequency

    private fun passesFrequency(survey: SurveyConfig, sessionCount: Int): Boolean {
        val freq = survey.frequency
        if (storage.completedCount(survey.surveyId) >= freq.maxPerUser) return false
        val lastShown = storage.lastShownDate(survey.surveyId)
        if (lastShown != null && freq.cooldownDays > 0) {
            val daysSince = TimeUnit.MILLISECONDS.toDays(
                System.currentTimeMillis() - lastShown.time
            )
            if (daysSince < freq.cooldownDays) return false
        }
        if (sessionCount >= freq.maxPerSession) return false
        return true
    }

    // MARK: - Trigger evaluation

    fun evaluateTrigger(
        trigger: Trigger,
        screen: String,
        countSource: CountSource
    ): Boolean = evaluate(trigger, screen, countSource)

    companion object {
        /** Pure, storage-free trigger evaluation. Exposed so unit tests can
         *  exercise the matching logic without an Android Context. */
        fun evaluate(
            trigger: Trigger,
            screen: String,
            countSource: CountSource
        ): Boolean {
            val screenOk = trigger.screens.isEmpty() ||
                trigger.screens.any { matchScreen(it, screen) }
            if (!screenOk) return false
            if (trigger.events.isEmpty()) return true
            val results = trigger.events.map { rule ->
                countSource.count(rule.eventName, rule.scope, screen) >= rule.count
            }
            return if (trigger.eventLogic == "any") results.any { it } else results.all { it }
        }

        private fun matchScreen(rule: ScreenRule, screen: String): Boolean {
            if (rule.value.isEmpty()) return true
            return try {
                val regex = when (rule.matchType) {
                    "name" -> "^${Pattern.quote(rule.value)}$"
                    "contains" -> ".*${Pattern.quote(rule.value)}.*"
                    "regex" -> rule.value
                    else -> return false
                }
                Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(screen).find()
            } catch (_: Exception) {
                false
            }
        }
    }
}
