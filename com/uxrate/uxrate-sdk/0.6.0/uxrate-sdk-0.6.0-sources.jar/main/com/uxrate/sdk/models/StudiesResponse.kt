package com.uxrate.sdk.models

import com.uxrate.sdk.services.ReplayConfig
import org.json.JSONArray
import org.json.JSONObject

/**
 * Wire format models for /api/sdk/init response.
 * Maps to iOS StudiesResponse and related Decodable structs.
 * Uses org.json manual parsing instead of Codable.
 */

data class StudiesResponse(
    val studies: List<Study>
) {
    companion object {
        fun fromJson(json: JSONObject): StudiesResponse {
            val studiesArray = json.optJSONArray("studies") ?: JSONArray()
            val studies = mutableListOf<Study>()
            for (i in 0 until studiesArray.length()) {
                studies.add(Study.fromJson(studiesArray.getJSONObject(i)))
            }
            return StudiesResponse(studies)
        }
    }
}

data class Study(
    val id: String,
    val name: String,
    val isActive: Boolean,
    val platform: String,
    val priority: Int,
    val appearance: StudyAppearance,
    /** New wire shape (PR 2). Null on older servers — legacy `targetTrigger` is
     *  used as a fallback in that case. */
    val triggers: List<TriggerWire>?,
    val targetTrigger: TargetTrigger?,
    val replayConfig: ReplayConfig? = null
) {
    companion object {
        fun fromJson(json: JSONObject): Study {
            val triggersArray = if (json.has("triggers") && !json.isNull("triggers")) {
                json.optJSONArray("triggers")
            } else null
            val triggers = triggersArray?.let { arr ->
                buildList {
                    for (i in 0 until arr.length()) {
                        add(TriggerWire.fromJson(arr.getJSONObject(i)))
                    }
                }
            }
            return Study(
                id = json.getString("id"),
                name = json.getString("name"),
                isActive = json.optBoolean("isActive", false),
                platform = json.optString("platform", ""),
                priority = json.optInt("priority", 0),
                appearance = StudyAppearance.fromJson(json.getJSONObject("appearance")),
                triggers = triggers,
                targetTrigger = json.optJSONObject("targetTrigger")?.let {
                    TargetTrigger.fromJson(it)
                },
                replayConfig = json.optJSONObject("replayConfig")?.let {
                    ReplayConfig.fromJson(it)
                }
            )
        }
    }
}

/** New per-study trigger as emitted by `/api/sdk/init` since PR 2.
 *  See `TRIGGERS_SPEC.md` §1. */
data class TriggerWire(
    val id: String?,
    val name: String?,
    val screens: List<ScreenTarget>,
    val events: List<EventRuleWire>,
    /** "all" (default) or "any". Matches `EventRule` semantics in the spec. */
    val eventLogic: String = "all"
) {
    companion object {
        fun fromJson(json: JSONObject): TriggerWire {
            val screensArray = json.optJSONArray("screens") ?: JSONArray()
            val screens = mutableListOf<ScreenTarget>()
            for (i in 0 until screensArray.length()) {
                screens.add(ScreenTarget.fromJson(screensArray.getJSONObject(i)))
            }

            val eventsArray = json.optJSONArray("events") ?: JSONArray()
            val events = mutableListOf<EventRuleWire>()
            for (i in 0 until eventsArray.length()) {
                events.add(EventRuleWire.fromJson(eventsArray.getJSONObject(i)))
            }

            val eventLogic = json.optString("eventLogic", "all").ifEmpty { "all" }
            val id = if (json.has("id") && !json.isNull("id")) json.optString("id") else null
            val name = if (json.has("name") && !json.isNull("name")) json.optString("name").ifEmpty { null } else null

            return TriggerWire(id, name, screens, events, eventLogic)
        }
    }
}

/** Wire format for `triggers[].events[]`. `count` defaults to 1, `scope`
 *  defaults to "session" when the server omits the field. */
data class EventRuleWire(
    val id: String?,
    val eventName: String,
    val count: Int,
    val scope: String
) {
    companion object {
        fun fromJson(json: JSONObject): EventRuleWire {
            return EventRuleWire(
                id = if (json.has("id") && !json.isNull("id")) json.optString("id") else null,
                eventName = json.optString("eventName", ""),
                count = json.optInt("count", 1).coerceAtLeast(1),
                scope = json.optString("scope", "session").ifEmpty { "session" }
            )
        }
    }
}

data class StudyAppearance(
    val headline: String,
    val subtext: String,
    val callToAction: String,
    val position: String?,
    /** Nav title rendered at the top of the survey chat screen. */
    val chatTitle: String,
    /** Optional per-study banner palette. Null when older backends omit it. */
    val colors: StudyBannerColors?
) {
    companion object {
        fun fromJson(json: JSONObject): StudyAppearance {
            val rawChatTitle = json.optString("chatTitle", "").trim()
            return StudyAppearance(
                headline = json.optString("headline", ""),
                subtext = json.optString("subtext", ""),
                callToAction = json.optString("callToAction", ""),
                position = json.optString("position", "navigation").takeIf { it.isNotEmpty() },
                chatTitle = rawChatTitle.ifEmpty { "Share your experience" },
                colors = json.optJSONObject("colors")?.let { StudyBannerColors.fromJson(it) }
            )
        }
    }
}

data class StudyBannerColors(
    val light: StudyBannerPalette?,
    val dark: StudyBannerPalette?
) {
    companion object {
        fun fromJson(json: JSONObject): StudyBannerColors {
            return StudyBannerColors(
                light = json.optJSONObject("light")?.let { StudyBannerPalette.fromJson(it) },
                dark = json.optJSONObject("dark")?.let { StudyBannerPalette.fromJson(it) }
            )
        }
    }
}

data class StudyBannerPalette(
    val background: String?,
    val text: String?,
    val primary: String?
) {
    companion object {
        fun fromJson(json: JSONObject): StudyBannerPalette {
            return StudyBannerPalette(
                background = json.optString("background", "").ifEmpty { null },
                text = json.optString("text", "").ifEmpty { null },
                primary = json.optString("primary", "").ifEmpty { null }
            )
        }
    }
}

data class TargetTrigger(
    val screens: List<ScreenTarget>,
    val events: List<EventTarget>,
    /**
     * "any" → fire when any configured event has occurred.
     * "all" (default) → every configured event must have occurred.
     * Older servers omit this field entirely.
     */
    val eventMatchLogic: String = "all",
    /** Legacy single-option frequency preset; still used when `caps` is
     *  absent so older studies keep their behaviour. */
    val frequency: String? = null,
    /** Per-event caps authored from the dashboard. */
    val caps: TargetCapsWire? = null
) {
    companion object {
        fun fromJson(json: JSONObject): TargetTrigger {
            val screensArray = json.optJSONArray("screens") ?: JSONArray()
            val screens = mutableListOf<ScreenTarget>()
            for (i in 0 until screensArray.length()) {
                screens.add(ScreenTarget.fromJson(screensArray.getJSONObject(i)))
            }

            val eventsArray = json.optJSONArray("events") ?: JSONArray()
            val events = mutableListOf<EventTarget>()
            for (i in 0 until eventsArray.length()) {
                events.add(EventTarget.fromJson(eventsArray.getJSONObject(i)))
            }

            val eventMatchLogic = json.optString("eventMatchLogic", "all")
                .ifEmpty { "all" }

            val frequency = if (json.has("frequency") && !json.isNull("frequency"))
                json.optString("frequency").ifEmpty { null }
            else null

            val caps = json.optJSONObject("caps")?.let { TargetCapsWire.fromJson(it) }

            return TargetTrigger(screens, events, eventMatchLogic, frequency, caps)
        }
    }
}

/** Wire format for `targetTrigger.caps`. See `TargetCaps` for the resolved shape. */
data class TargetCapsWire(
    val bannerShown: CapEntryWire?,
    val bannerDismissed: CapEntryWire?,
    val surveyStarted: CapEntryWire?,
    val surveyCompleted: CapEntryWire?
) {
    companion object {
        fun fromJson(json: JSONObject): TargetCapsWire =
            TargetCapsWire(
                bannerShown = json.optJSONObject("banner_shown")?.let { CapEntryWire.fromJson(it) },
                bannerDismissed = json.optJSONObject("banner_dismissed")?.let { CapEntryWire.fromJson(it) },
                surveyStarted = json.optJSONObject("survey_started")?.let { CapEntryWire.fromJson(it) },
                surveyCompleted = json.optJSONObject("survey_completed")?.let { CapEntryWire.fromJson(it) },
            )
    }
}

data class CapEntryWire(val max: Int, val scope: String) {
    companion object {
        fun fromJson(json: JSONObject): CapEntryWire =
            CapEntryWire(
                max = json.optInt("max", 0),
                scope = json.optString("scope", ""),
            )
    }
}

data class ScreenTarget(
    val id: String?,
    val value: String,
    val matchType: String
) {
    companion object {
        fun fromJson(json: JSONObject): ScreenTarget {
            return ScreenTarget(
                id = if (json.has("id")) json.optString("id") else null,
                value = json.optString("value", ""),
                matchType = json.optString("matchType", "name")
            )
        }
    }
}

data class EventTarget(
    val id: String?,
    val eventName: String,
    val operator: String, // "is" | "fired_gte" | "fired_exactly"
    val value: String?
) {
    companion object {
        fun fromJson(json: JSONObject): EventTarget {
            return EventTarget(
                id = if (json.has("id")) json.optString("id") else null,
                eventName = json.optString("eventName", ""),
                operator = json.optString("operator", "is"),
                value = if (json.has("value")) json.optString("value") else null
            )
        }
    }
}
