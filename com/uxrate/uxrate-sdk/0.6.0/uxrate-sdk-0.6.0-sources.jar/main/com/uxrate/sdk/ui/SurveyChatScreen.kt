package com.uxrate.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uxrate.sdk.SurveyManager
import com.uxrate.sdk.ui.theme.UXRateColors
import kotlinx.coroutines.launch

/**
 * Chat screen composable for the survey conversation.
 * Maps to iOS SurveyChatView.
 *
 * LazyColumn of chat bubbles + typing indicator + input bar
 * Auto-scroll on new messages
 * "Return to App" green button when completed
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurveyChatScreen(
    manager: SurveyManager,
    onClose: () -> Unit
) {
    val messages by manager.messages.collectAsState()
    val isLoadingResponse by manager.isLoadingResponse.collectAsState()
    val isChatCompleted by manager.isChatCompleted.collectAsState()
    val isChatErrored by manager.isChatErrored.collectAsState()
    val activeSurveyState by manager.activeSurveyState.collectAsState()
    val chatTitle = activeSurveyState?.chatTitle?.takeIf { it.isNotBlank() }
        ?: "Share your experience"

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Auto-scroll to bottom when new messages arrive
    LaunchedEffect(messages.size, isLoadingResponse) {
        if (messages.isNotEmpty() || isLoadingResponse) {
            coroutineScope.launch {
                // Scroll to the last item (typing indicator counts as extra)
                val targetIndex = messages.size + (if (isLoadingResponse) 0 else -1)
                if (targetIndex >= 0) {
                    listState.animateScrollToItem(targetIndex.coerceAtLeast(0))
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(chatTitle) },
                navigationIcon = {
                    TextButton(onClick = onClose) {
                        Text(
                            "Close",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Chat messages
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatBubble(message = message)
                }

                if (isLoadingResponse) {
                    item {
                        TypingIndicator()
                    }
                }
            }

            // Divider
            HorizontalDivider()

            // Input bar, "Return to App" (completed) or "Close" (errored).
            // The error branch exists so a user never sees an enabled text
            // field after createSession() failed — typing into a dead chat
            // would just queue messages the backend cannot route.
            when {
                isChatCompleted -> {
                    Button(
                        onClick = onClose,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = UXRateColors.returnButtonBackground,
                            contentColor = androidx.compose.ui.graphics.Color.White
                        ),
                        contentPadding = PaddingValues(vertical = 14.dp)
                    ) {
                        Text(
                            text = "Return to App",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                isChatErrored -> {
                    Button(
                        onClick = onClose,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(vertical = 14.dp)
                    ) {
                        Text(
                            text = "Close",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                else -> {
                    ChatInputBar(
                        isDisabled = isLoadingResponse,
                        onSend = { text ->
                            manager.sendMessage(text)
                        }
                    )
                }
            }
        }
    }
}
