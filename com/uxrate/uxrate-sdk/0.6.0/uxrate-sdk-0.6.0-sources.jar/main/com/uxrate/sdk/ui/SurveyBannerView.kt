package com.uxrate.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uxrate.sdk.models.BannerColorTokens
import com.uxrate.sdk.ui.theme.UXRateColors

/**
 * Survey banner card shown as an overlay.
 * Maps to iOS SurveyFloatingButton (SurveyBannerView).
 *
 * Card: 14dp corner radius, 16dp padding
 * Shadow: 12dp blur, 4dp y-offset
 * Close button: 28dp circle
 * CTA button: 8dp corner radius
 */
@Composable
fun SurveyBannerView(
    headline: String,
    subtext: String,
    callToAction: String,
    isDark: Boolean,
    tokens: BannerColorTokens,
    onStartSurvey: () -> Unit,
    onDismiss: () -> Unit
) {
    // Derive the full render palette from three author-controlled tokens
    // (background / text / primary) plus the light-or-dark mode. CTA text
    // uses the mode's own background (navy-on-white / white-on-navy
    // inversion); subtext/close colors derive from `text` at reduced alpha.
    val cardBackground = tokens.background.toComposeColor(fallback = UXRateColors.bannerBackgroundLight)
    val textColor = tokens.text.toComposeColor(fallback = Color.Black)
    val primaryColor = tokens.primary.toComposeColor(fallback = UXRateColors.ctaBackgroundLight)
    val headlineColor = textColor
    val subtextColor = textColor.copy(alpha = 0.7f)
    val ctaBackground = primaryColor
    val ctaTextColor = cardBackground
    val shadowColor = if (isDark) UXRateColors.shadowDark else UXRateColors.shadowLight
    val borderColor = textColor.copy(alpha = if (isDark) 0.18f else 0.12f)
    val closeCircleBg = if (isDark) textColor.copy(alpha = 0.1f) else Color.Transparent
    val closeIconColor = textColor.copy(alpha = 0.65f)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(14.dp),
                ambientColor = shadowColor,
                spotColor = shadowColor
            )
            .clip(RoundedCornerShape(14.dp))
            .background(cardBackground)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        // Top section: headline + subtext + close button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    // Fallback to a neutral prompt so the banner never shows
                    // the study's internal name (e.g. "Study") or a blank
                    // headline when the admin hasn't customized the copy.
                    text = headline.ifBlank { "Share your experience" },
                    color = headlineColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtext,
                    color = subtextColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal
                )
            }

            // Close button — 48dp hit target (Material minimum) with a 28dp
            // visual circle centered inside, so the button stays visually
            // compact but is reliably tappable.
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable { onDismiss() },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(closeCircleBg)
                        .then(
                            if (isDark) Modifier
                            else Modifier.border(1.dp, borderColor, CircleShape)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Dismiss",
                        tint = closeIconColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // CTA button
        Button(
            onClick = onStartSurvey,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = ctaBackground,
                contentColor = ctaTextColor
            ),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            Text(
                text = callToAction,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/**
 * Parse a `#RRGGBB` literal into a Compose `Color`. Falls back to the
 * supplied default on malformed input so a single bad hex never crashes
 * the banner.
 */
private fun String.toComposeColor(fallback: Color): Color {
    val cleaned = trim().removePrefix("#")
    if (cleaned.length != 6) return fallback
    val parsed = cleaned.toLongOrNull(16) ?: return fallback
    val r = ((parsed shr 16) and 0xFF).toInt()
    val g = ((parsed shr 8) and 0xFF).toInt()
    val b = (parsed and 0xFF).toInt()
    return Color(red = r, green = g, blue = b)
}
