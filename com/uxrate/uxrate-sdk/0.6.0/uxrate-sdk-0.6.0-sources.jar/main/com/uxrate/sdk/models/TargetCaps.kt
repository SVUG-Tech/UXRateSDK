package com.uxrate.sdk.models

/**
 * Per-event caps authored from the dashboard Target & Trigger panel.
 *
 * Each of four lifecycle events can be capped independently. `null` means
 * no cap. `scope` controls the counting window:
 *
 *   SESSION — resets on every SDK launch (tracked in-memory by SurveyManager)
 *   DAY     — rolling 24h window, counted from `LocalStorage.capDayCount`
 *   USER    — lifetime, backed by `LocalStorage.capLifetimeCount`
 *
 * Legacy studies encode cadence through `targetTrigger.frequency`; the
 * [resolveTargetCaps] helper translates that into the same shape so the rest
 * of the SDK only needs to handle one model.
 */
data class TargetCaps(
    val bannerShown: CapEntry? = null,
    val bannerDismissed: CapEntry? = null,
    val surveyStarted: CapEntry? = null,
    val surveyCompleted: CapEntry? = null,
) {
    fun entry(event: CapEvent): CapEntry? = when (event) {
        CapEvent.BANNER_SHOWN -> bannerShown
        CapEvent.BANNER_DISMISSED -> bannerDismissed
        CapEvent.SURVEY_STARTED -> surveyStarted
        CapEvent.SURVEY_COMPLETED -> surveyCompleted
    }

    companion object {
        val UNLIMITED = TargetCaps()
    }
}

data class CapEntry(val max: Int, val scope: CapScope)

enum class CapScope(val wire: String) {
    SESSION("session"),
    DAY("day"),
    USER("user");

    companion object {
        fun fromWire(value: String?): CapScope? =
            values().firstOrNull { it.wire == value }
    }
}

enum class CapEvent(val wire: String) {
    BANNER_SHOWN("banner_shown"),
    BANNER_DISMISSED("banner_dismissed"),
    SURVEY_STARTED("survey_started"),
    SURVEY_COMPLETED("survey_completed");
}

/**
 * Map the wire-format caps (and optional legacy `frequency`) to an
 * authoritative [TargetCaps]. Uses `caps` when any event has an entry;
 * otherwise derives from `frequency` so existing studies keep working.
 */
fun resolveTargetCaps(
    caps: TargetCapsWire?,
    frequency: String?,
): TargetCaps {
    if (caps != null && hasAnyEntry(caps)) {
        return TargetCaps(
            bannerShown = capEntryOrNull(caps.bannerShown),
            bannerDismissed = capEntryOrNull(caps.bannerDismissed),
            surveyStarted = capEntryOrNull(caps.surveyStarted),
            surveyCompleted = capEntryOrNull(caps.surveyCompleted),
        )
    }
    return capsFromLegacyFrequency(frequency)
}

private fun hasAnyEntry(caps: TargetCapsWire): Boolean =
    caps.bannerShown != null
        || caps.bannerDismissed != null
        || caps.surveyStarted != null
        || caps.surveyCompleted != null

private fun capEntryOrNull(wire: CapEntryWire?): CapEntry? {
    if (wire == null || wire.max < 1) return null
    val scope = CapScope.fromWire(wire.scope) ?: return null
    return CapEntry(max = wire.max, scope = scope)
}

/** Translate the pre-caps `frequency` dropdown into the caps shape. Same
 *  mapping the dashboard uses when it seeds the UI. */
fun capsFromLegacyFrequency(frequency: String?): TargetCaps = when (frequency) {
    "once_per_user" -> TargetCaps(surveyCompleted = CapEntry(max = 1, scope = CapScope.USER))
    "once_per_day" -> TargetCaps(surveyCompleted = CapEntry(max = 1, scope = CapScope.DAY))
    "once_per_session" -> TargetCaps(surveyStarted = CapEntry(max = 1, scope = CapScope.SESSION))
    // every_time, null, unknown — no caps.
    else -> TargetCaps.UNLIMITED
}
