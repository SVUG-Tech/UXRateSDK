package com.uxrate.sdk.models

/**
 * The backend environment for the UXRate SDK.
 */
enum class Environment(val baseURL: String?) {
    /** Production backend (default). */
    PRODUCTION("https://app.uxrate.com"),
    /** Development/staging backend. */
    DEVELOPMENT("https://app-dev.uxrate.com"),
    /** Local development server. Uses 10.0.2.2 for Android emulator localhost. */
    LOCAL("http://10.0.2.2:3000"),
    /** Built-in mock service — no network calls. Great for quick SDK evaluation. */
    MOCK(null);

    companion object {
        fun from(name: String?): Environment = when (name?.lowercase()) {
            "development", "dev" -> DEVELOPMENT
            "local" -> LOCAL
            "mock" -> MOCK
            else -> PRODUCTION
        }
    }
}
