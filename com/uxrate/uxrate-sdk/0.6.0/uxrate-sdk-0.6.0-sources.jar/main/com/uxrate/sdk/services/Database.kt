package com.uxrate.sdk.services

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * SQLite database for all SDK persistence.
 * Uses WAL mode for concurrent reads and SQLiteOpenHelper for schema management.
 * Replaces SharedPreferences for better crash safety, query capability, and auto-cleanup.
 */
class Database(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "uxrate.db"
        private const val DB_VERSION = 2
        private const val TAG = "UXRate"

        fun iso8601(date: Date): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            return sdf.format(date)
        }

        fun dateFromISO8601(string: String): Date? {
            return try {
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                sdf.parse(string)
            } catch (_: Exception) {
                try {
                    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                    sdf.timeZone = TimeZone.getTimeZone("UTC")
                    sdf.parse(string)
                } catch (_: Exception) {
                    null
                }
            }
        }
    }

    private val appContext: Context = context.applicationContext

    init {
        writableDatabase.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE key_value (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        db.execSQL("""
            CREATE TABLE user_properties (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        db.execSQL("""
            CREATE TABLE counters (
                category   TEXT NOT NULL,
                name       TEXT NOT NULL,
                count      INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (category, name)
            )
        """)
        db.execSQL("""
            CREATE TABLE survey_state (
                survey_id       TEXT PRIMARY KEY,
                last_shown_at   TEXT,
                completed_count INTEGER NOT NULL DEFAULT 0
            )
        """)
        db.execSQL("""
            CREATE TABLE events (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                type       TEXT NOT NULL,
                timestamp  TEXT NOT NULL,
                name       TEXT,
                properties TEXT,
                study_id   TEXT,
                count      INTEGER DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)
        createCapCountsTable(db)

        migrateFromSharedPreferences(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createCapCountsTable(db)
    }

    /** Per-event counters used by Target & Trigger caps. For each
     *  (survey, event) we track lifetime + a daily bucket keyed by
     *  `YYYY-MM-DD` (reset lazily on the next write). */
    private fun createCapCountsTable(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS cap_counts (
                survey_id      TEXT NOT NULL,
                event          TEXT NOT NULL,
                lifetime_count INTEGER NOT NULL DEFAULT 0,
                day_count      INTEGER NOT NULL DEFAULT 0,
                day_key        TEXT,
                last_at        TEXT,
                PRIMARY KEY (survey_id, event)
            )
        """)
    }

    // MARK: - Migration from SharedPreferences

    private fun migrateFromSharedPreferences(db: SQLiteDatabase) {
        val prefs = appContext.getSharedPreferences("uxrate_sdk", Context.MODE_PRIVATE)
        val allKeys = prefs.all.keys.filter { it.startsWith("uxrate.") }
        if (allKeys.isEmpty()) return

        db.beginTransaction()
        try {
            val now = iso8601(Date())

            // Participant ID
            prefs.getString("uxrate.participantId", null)?.let {
                db.execSQL("INSERT OR IGNORE INTO key_value (key, value) VALUES (?, ?)",
                    arrayOf("participant_id", it))
            }

            // Install date
            val installTs = prefs.getLong("uxrate.installDate", 0L)
            if (installTs != 0L) {
                db.execSQL("INSERT OR IGNORE INTO key_value (key, value) VALUES (?, ?)",
                    arrayOf("install_date", iso8601(Date(installTs))))
            }

            // User ID
            prefs.getString("uxrate.userId", null)?.let {
                db.execSQL("INSERT OR IGNORE INTO key_value (key, value) VALUES (?, ?)",
                    arrayOf("user_id", it))
            }

            // Config cache
            prefs.getString("uxrate.configCache", null)?.let {
                db.execSQL("INSERT OR IGNORE INTO key_value (key, value) VALUES (?, ?)",
                    arrayOf("config_cache", it))
            }
            val cacheExpiry = prefs.getLong("uxrate.configCacheExpiry", 0L)
            if (cacheExpiry != 0L) {
                db.execSQL("INSERT OR IGNORE INTO key_value (key, value) VALUES (?, ?)",
                    arrayOf("config_cache_expiry", iso8601(Date(cacheExpiry))))
            }

            // User properties
            prefs.getString("uxrate.userProperties", null)?.let { propsString ->
                try {
                    val json = JSONObject(propsString)
                    json.keys().forEach { key ->
                        db.execSQL("INSERT OR IGNORE INTO user_properties (key, value) VALUES (?, ?)",
                            arrayOf(key, json.optString(key)))
                    }
                } catch (_: Exception) { }
            }

            // Visit counts
            for (key in allKeys.filter { it.startsWith("uxrate.visits.") }) {
                val screen = key.removePrefix("uxrate.visits.")
                val count = prefs.getInt(key, 0)
                if (count > 0) {
                    db.execSQL("INSERT OR IGNORE INTO counters (category, name, count, updated_at) VALUES (?, ?, ?, ?)",
                        arrayOf("visit", screen, count.toString(), now))
                }
            }

            // Event counts
            for (key in allKeys.filter { it.startsWith("uxrate.events.") }) {
                val event = key.removePrefix("uxrate.events.")
                val count = prefs.getInt(key, 0)
                if (count > 0) {
                    db.execSQL("INSERT OR IGNORE INTO counters (category, name, count, updated_at) VALUES (?, ?, ?, ?)",
                        arrayOf("event", event, count.toString(), now))
                }
            }

            // Daily survey counts
            for (key in allKeys.filter { it.startsWith("uxrate.dailyCount.") }) {
                val date = key.removePrefix("uxrate.dailyCount.")
                val count = prefs.getInt(key, 0)
                if (count > 0) {
                    db.execSQL("INSERT OR IGNORE INTO counters (category, name, count, updated_at) VALUES (?, ?, ?, ?)",
                        arrayOf("daily_survey", date, count.toString(), now))
                }
            }

            // Survey state
            for (key in allKeys.filter { it.startsWith("uxrate.lastShown.") }) {
                val surveyId = key.removePrefix("uxrate.lastShown.")
                val ts = prefs.getLong(key, 0L)
                if (ts != 0L) {
                    db.execSQL("""
                        INSERT INTO survey_state (survey_id, last_shown_at, completed_count)
                        VALUES (?, ?, 0)
                        ON CONFLICT(survey_id) DO UPDATE SET last_shown_at = excluded.last_shown_at
                    """, arrayOf(surveyId, iso8601(Date(ts))))
                }
            }
            for (key in allKeys.filter { it.startsWith("uxrate.completed.") }) {
                val surveyId = key.removePrefix("uxrate.completed.")
                val count = prefs.getInt(key, 0)
                if (count > 0) {
                    db.execSQL("""
                        INSERT INTO survey_state (survey_id, last_shown_at, completed_count)
                        VALUES (?, NULL, ?)
                        ON CONFLICT(survey_id) DO UPDATE SET completed_count = excluded.completed_count
                    """, arrayOf(surveyId, count.toString()))
                }
            }

            // Pending events
            prefs.getString("uxrate.pendingEvents", null)?.let { json ->
                try {
                    val array = JSONArray(json)
                    for (i in 0 until array.length()) {
                        val item = array.getJSONObject(i)
                        db.execSQL("""
                            INSERT INTO events (type, timestamp, name, properties, study_id, count)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, arrayOf<Any?>(
                            item.getString("type"),
                            item.getString("timestamp"),
                            item.optString("name", ""),
                            if (item.has("properties")) item.getJSONObject("properties").toString() else "",
                            item.optString("studyId", ""),
                            item.optInt("count", 1).toString()
                        ))
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to migrate pending events: ${e.message}")
                }
            }

            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        // Clear old SharedPreferences
        val editor = prefs.edit()
        for (key in allKeys) {
            editor.remove(key)
        }
        editor.apply()
    }

    // MARK: - Query Helpers

    /**
     * Query returning a single scalar string value, or null.
     */
    fun scalar(sql: String, vararg args: String): String? {
        readableDatabase.rawQuery(sql, args).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }

    /**
     * Query returning a single integer value (defaults to 0).
     */
    fun scalarInt(sql: String, vararg args: String): Int {
        return scalar(sql, *args)?.toIntOrNull() ?: 0
    }

    /**
     * Query returning rows as list of maps.
     */
    fun queryRows(sql: String, vararg args: String): List<Map<String, String>> {
        val rows = mutableListOf<Map<String, String>>()
        readableDatabase.rawQuery(sql, args).use { cursor ->
            while (cursor.moveToNext()) {
                val row = mutableMapOf<String, String>()
                for (i in 0 until cursor.columnCount) {
                    cursor.getString(i)?.let { row[cursor.getColumnName(i)] = it }
                }
                rows.add(row)
            }
        }
        return rows
    }

    /**
     * Execute a write statement with parameters.
     */
    fun exec(sql: String, vararg args: Any?) {
        writableDatabase.execSQL(sql, args)
    }
}
