package com.uxrate.sdk.services

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * SQLite-backed persistence for all SDK state.
 * Thread safety is handled by SQLite's WAL mode — no manual locking needed.
 * All method signatures are preserved so callers require zero changes.
 */
class LocalStorage(context: Context) {

    private val db: Database = Database(context)

    // Daily-cap boundary is anchored to UTC so it aligns with the UTC timestamps
    // written to the `counters` / `events` tables. Without this, the day key
    // uses the device's local timezone and drifts from the stored data by the
    // UTC offset (see UXRateSDK-Android#12).
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    /** Expose the database for EventQueue direct access. */
    internal val database: Database get() = db

    // MARK: - Participant ID

    val participantId: String
        get() {
            db.scalar("SELECT value FROM key_value WHERE key = ?", "participant_id")?.let { return it }
            val newId = UUID.randomUUID().toString()
            db.exec("INSERT OR IGNORE INTO key_value (key, value) VALUES (?, ?)",
                "participant_id", newId)
            return newId
        }

    // MARK: - Install Date

    val installDate: Date
        get() {
            db.scalar("SELECT value FROM key_value WHERE key = ?", "install_date")?.let { str ->
                Database.dateFromISO8601(str)?.let { return it }
            }
            val now = Date()
            db.exec("INSERT OR IGNORE INTO key_value (key, value) VALUES (?, ?)",
                "install_date", Database.iso8601(now))
            return now
        }

    // MARK: - Visit Counts

    fun visitCount(screenName: String): Int =
        db.scalarInt("SELECT count FROM counters WHERE category = 'visit' AND name = ?", screenName)

    fun incrementVisit(screenName: String) {
        db.exec("""
            INSERT INTO counters (category, name, count, updated_at) VALUES ('visit', ?, 1, datetime('now'))
            ON CONFLICT(category, name) DO UPDATE SET count = count + 1, updated_at = datetime('now')
        """, screenName)
    }

    // MARK: - Event Counts

    fun eventCount(eventName: String): Int =
        db.scalarInt("SELECT count FROM counters WHERE category = 'event' AND name = ?", eventName)

    fun incrementEvent(eventName: String) {
        db.exec("""
            INSERT INTO counters (category, name, count, updated_at) VALUES ('event', ?, 1, datetime('now'))
            ON CONFLICT(category, name) DO UPDATE SET count = count + 1, updated_at = datetime('now')
        """, eventName)
    }

    // MARK: - Survey Tracking

    fun lastShownDate(surveyId: String): Date? {
        val str = db.scalar("SELECT last_shown_at FROM survey_state WHERE survey_id = ?", surveyId)
            ?: return null
        return Database.dateFromISO8601(str)
    }

    fun recordShown(surveyId: String) {
        val now = Database.iso8601(Date())
        db.exec("""
            INSERT INTO survey_state (survey_id, last_shown_at, completed_count) VALUES (?, ?, 0)
            ON CONFLICT(survey_id) DO UPDATE SET last_shown_at = ?
        """, surveyId, now, now)
    }

    fun completedCount(surveyId: String): Int =
        db.scalarInt("SELECT completed_count FROM survey_state WHERE survey_id = ?", surveyId)

    fun recordCompleted(surveyId: String) {
        db.exec("""
            INSERT INTO survey_state (survey_id, last_shown_at, completed_count) VALUES (?, NULL, 1)
            ON CONFLICT(survey_id) DO UPDATE SET completed_count = completed_count + 1
        """, surveyId)
    }

    // MARK: - User Properties

    fun getUserProperties(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        for (row in db.queryRows("SELECT key, value FROM user_properties")) {
            val k = row["key"] ?: continue
            val v = row["value"] ?: continue
            result[k] = v
        }
        return result
    }

    fun setUserProperties(properties: Map<String, String>) {
        for ((key, value) in properties) {
            db.exec("INSERT OR REPLACE INTO user_properties (key, value) VALUES (?, ?)", key, value)
        }
    }

    fun setUserId(userId: String) {
        db.exec("INSERT OR REPLACE INTO key_value (key, value) VALUES (?, ?)", "user_id", userId)
    }

    fun getUserId(): String? =
        db.scalar("SELECT value FROM key_value WHERE key = ?", "user_id")

    // MARK: - Config Cache

    fun getCachedConfigData(): String? =
        db.scalar("SELECT value FROM key_value WHERE key = ?", "config_cache")

    fun getConfigCacheExpiry(): Date? {
        val str = db.scalar("SELECT value FROM key_value WHERE key = ?", "config_cache_expiry")
            ?: return null
        return Database.dateFromISO8601(str)
    }

    fun saveConfigCache(data: String, expiry: Date) {
        db.exec("INSERT OR REPLACE INTO key_value (key, value) VALUES (?, ?)", "config_cache", data)
        db.exec("INSERT OR REPLACE INTO key_value (key, value) VALUES (?, ?)",
            "config_cache_expiry", Database.iso8601(expiry))
    }

    // MARK: - Daily Survey Count

    fun todaySurveyCount(): Int {
        val todayKey = dateFormat.format(Date())
        return db.scalarInt("SELECT count FROM counters WHERE category = 'daily_survey' AND name = ?", todayKey)
    }

    fun incrementTodaySurveyCount() {
        val todayKey = dateFormat.format(Date())
        db.exec("""
            INSERT INTO counters (category, name, count, updated_at) VALUES ('daily_survey', ?, 1, datetime('now'))
            ON CONFLICT(category, name) DO UPDATE SET count = count + 1, updated_at = datetime('now')
        """, todayKey)
    }

    // MARK: - Cleanup

    /** Prune stale data. Call on each configure(). */
    fun cleanup(activeSurveyIds: List<String> = emptyList()) {
        db.writableDatabase.execSQL("DELETE FROM counters WHERE category = 'daily_survey' AND name < date('now', '-7 days')")
        db.writableDatabase.execSQL("DELETE FROM counters WHERE updated_at < datetime('now', '-90 days')")
        db.writableDatabase.execSQL("DELETE FROM events WHERE created_at < datetime('now', '-7 days')")

        if (activeSurveyIds.isNotEmpty()) {
            val placeholders = activeSurveyIds.joinToString(", ") { "?" }
            db.writableDatabase.execSQL(
                "DELETE FROM survey_state WHERE survey_id NOT IN ($placeholders)",
                activeSurveyIds.toTypedArray()
            )
        }
    }
}
