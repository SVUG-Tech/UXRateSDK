package com.uxrate.sdk.services

import com.uxrate.sdk.models.CodableValue
import com.uxrate.sdk.models.SDKConfig
import com.uxrate.sdk.models.SurveyConfig
import java.util.Date
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Evaluates trigger rules to determine which surveys should be shown.
 * Maps to iOS TriggerEvaluator struct.
 */
class TriggerEvaluator(private val storage: LocalStorage) {

    /**
     * Returns ALL surveys that match the current context.
     * Order matches config.surveys array.
     */
    fun matchingSurveys(
        screen: String,
        config: SDKConfig,
        sessionCount: Int
    ): List<SurveyConfig> {
        return config.surveys.filter { survey ->
            passesFrequency(survey, sessionCount) &&
                survey.triggers.all { rule ->
                    evaluate(rule.type, rule.conditions, screen, survey.surveyId)
                }
        }.sortedByDescending { it.priority }
        // Server already returns priority-ordered, but we re-sort here so
        // the SDK's overlap strategy (showFirst/showLast) always honors
        // priority regardless of server ordering.
    }

    /**
     * Convenience: returns first matching survey.
     * Equivalent to .showFirst strategy.
     */
    fun survey(
        screen: String,
        config: SDKConfig,
        sessionCount: Int
    ): SurveyConfig? {
        return matchingSurveys(screen, config, sessionCount).firstOrNull()
    }

    // MARK: - Frequency Checks

    private fun passesFrequency(survey: SurveyConfig, sessionCount: Int): Boolean {
        val freq = survey.frequency

        // Per-user completion cap
        if (storage.completedCount(survey.surveyId) >= freq.maxPerUser) {
            return false
        }

        // Cooldown since last shown
        val lastShown = storage.lastShownDate(survey.surveyId)
        if (lastShown != null && freq.cooldownDays > 0) {
            val daysSince = TimeUnit.MILLISECONDS.toDays(
                System.currentTimeMillis() - lastShown.time
            )
            if (daysSince < freq.cooldownDays) {
                return false
            }
        }

        // Per-session cap
        if (sessionCount >= freq.maxPerSession) {
            return false
        }

        return true
    }

    // MARK: - Rule Evaluation

    private fun evaluate(
        type: String,
        conditions: Map<String, CodableValue>,
        screen: String,
        surveyId: String
    ): Boolean {
        return when (type) {
            "page_visit" -> evaluatePageVisit(conditions, screen)
            "time_based" -> evaluateTimeBased(conditions)
            "event" -> evaluateEvent(conditions)
            "user_segment" -> evaluateUserSegment(conditions)
            else -> true // Unknown rule types fail-open
        }
    }

    // MARK: - Rule Type Handlers

    private fun evaluatePageVisit(
        conditions: Map<String, CodableValue>,
        screen: String
    ): Boolean {
        val pagePattern = conditions["pagePattern"]?.stringValue ?: return false
        val visitCount = conditions["visitCount"]?.intValue ?: 1

        return try {
            val pattern = Pattern.compile(pagePattern, Pattern.CASE_INSENSITIVE)
            val matches = pattern.matcher(screen).find()
            val currentVisits = storage.visitCount(screen)
            matches && currentVisits >= visitCount
        } catch (e: Exception) {
            false
        }
    }

    private fun evaluateTimeBased(conditions: Map<String, CodableValue>): Boolean {
        val daysAfterInstall = conditions["daysAfterInstall"]?.intValue ?: return false

        val daysSinceInstall = TimeUnit.MILLISECONDS.toDays(
            System.currentTimeMillis() - storage.installDate.time
        )
        return daysSinceInstall >= daysAfterInstall
    }

    private fun evaluateEvent(conditions: Map<String, CodableValue>): Boolean {
        val eventName = conditions["eventName"]?.stringValue ?: return false
        val requiredCount = conditions["count"]?.intValue ?: 1

        return storage.eventCount(eventName) >= requiredCount
    }

    private fun evaluateUserSegment(conditions: Map<String, CodableValue>): Boolean {
        val property = conditions["property"]?.stringValue ?: return false
        val value = conditions["value"]?.stringValue ?: return false

        val userProps = storage.getUserProperties()
        return userProps[property] == value
    }
}
