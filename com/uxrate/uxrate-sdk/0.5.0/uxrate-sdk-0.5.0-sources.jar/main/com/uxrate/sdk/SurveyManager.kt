package com.uxrate.sdk

import android.util.Log
import com.uxrate.sdk.models.*
import com.uxrate.sdk.services.EventQueue
import com.uxrate.sdk.services.LocalStorage
import com.uxrate.sdk.services.SdkEventItem
import com.uxrate.sdk.services.ReplayCapture
import com.uxrate.sdk.services.SurveyService
import com.uxrate.sdk.services.TriggerEvaluator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Central state manager for the UXRate SDK.
 * Maps to iOS SurveyManager (@Observable class).
 *
 * Uses MutableStateFlow for reactive state (equivalent to SwiftUI @Observable).
 * All state mutations dispatched on Main thread.
 */
class SurveyManager(
    private val service: SurveyService,
    val storage: LocalStorage,
    val overlapStrategy: OverlapStrategy,
    val theme: SDKTheme,
    internal val eventQueue: EventQueue? = null,
    val baseURL: String = "https://app.uxrate.com"
) {
    companion object {
        private const val TAG = "UXRate"
    }

    // Coroutine scope for async operations
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // MARK: - Configuration State

    private var isConfigured = false
    private var sdkConfig: SDKConfig? = null

    // MARK: - Locale

    /** Locale override set via UXRate.setLocale(). Null = use device locale. */
    var localeOverride: java.util.Locale? = null
        set(value) {
            field = value
            (service as? com.uxrate.sdk.services.LiveSurveyService)?.localeOverride = value
            if (isConfigured) refetchConfiguration()
        }

    /** Stored API key for re-fetching config on locale change. */
    private var storedApiKey: String? = null

    // MARK: - Screen Tracking

    private var currentScreen: String? = null
    var pendingManualScreen: String? = null

    // MARK: - Survey State

    private val _activeSurveyState = MutableStateFlow<ActiveSurveyState?>(null)
    val activeSurveyState: StateFlow<ActiveSurveyState?> = _activeSurveyState.asStateFlow()

    private val _shouldShowBanner = MutableStateFlow(false)
    val shouldShowBanner: StateFlow<Boolean> = _shouldShowBanner.asStateFlow()

    // Session-only guards. Keyed by surveyId so dismissing on screen A also
    // prevents the same study from re-showing on screen B (see Android#13).
    // Completion set mirrors server-side filtering until it lands (see
    // uxrate#136) — defends against stale cached configs.
    private val dismissedStudies = mutableSetOf<String>()
    private val completedStudies = mutableSetOf<String>()

    // MARK: - Chat State

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoadingResponse = MutableStateFlow(false)
    val isLoadingResponse: StateFlow<Boolean> = _isLoadingResponse.asStateFlow()

    private val _isChatCompleted = MutableStateFlow(false)
    val isChatCompleted: StateFlow<Boolean> = _isChatCompleted.asStateFlow()

    private val _isChatPresented = MutableStateFlow(false)
    val isChatPresented: StateFlow<Boolean> = _isChatPresented.asStateFlow()

    // MARK: - Frequency Tracking

    private var sessionSurveyCount = 0
    private val evaluator = TriggerEvaluator(storage)

    // MARK: - Replay

    var replayCapture: ReplayCapture? = null
    private var fallbackStudyId: String? = null

    // MARK: - Core Methods

    /**
     * Fetches configuration from the backend and marks SDK as configured.
     * Maps to iOS SurveyManager.configure(apiKey:)
     */
    suspend fun configure(apiKey: String) {
        storedApiKey = apiKey
        sessionSurveyCount = 0
        dismissedStudies.clear()
        completedStudies.clear()

        try {
            val config = service.fetchConfiguration(apiKey, storage.participantId)
            sdkConfig = config
            isConfigured = true

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "SDK configured with ${config.surveys.size} surveys")
            }

            // Initialize replay capture if any survey has replay config enabled
            val firstReplayConfig = config.surveys
                .mapNotNull { it.replayConfig }
                .firstOrNull { it.scope != "off" }

            if (firstReplayConfig != null) {
                val capture = ReplayCapture(baseURL = baseURL, apiKey = apiKey)
                capture.configure(firstReplayConfig, storage.participantId)

                // Wire the periodic flush handler
                capture.flushHandler = { cap ->
                    val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
                    scope.launch(Dispatchers.IO) {
                        try { cap.flushBuffer(studyId) } catch (_: Exception) {}
                    }
                }

                // Store fallback studyId for flushes when no active survey
                fallbackStudyId = config.surveys.firstOrNull()?.surveyId

                replayCapture = capture

                if (UXRate.loggingEnabled) {
                    Log.d(TAG, "Replay configured: scope=${firstReplayConfig.scope}, trigger=${firstReplayConfig.trigger}, armed=${firstReplayConfig.trigger == "triggered"}")
                }
            }

            // Evaluate in case screen tracking already fired before config was ready
            evaluateAndShow()
        } catch (e: Exception) {
            if (UXRate.loggingEnabled) {
                Log.e(TAG, "Failed to configure SDK: ${e.message}")
            }
        }
    }

    /**
     * Re-fetches the SDK configuration without touching session state.
     * Unlike [configure], this does NOT reset `sessionSurveyCount` or
     * clear dismissed/completed guards — so an admin config edit (or a
     * locale change) doesn't undo the host app's session-level frequency
     * tracking.
     *
     * Triggers a fresh `evaluateAndShow()` so a newly-activated study can
     * surface on the current screen immediately.
     */
    suspend fun refreshConfig(apiKey: String) {
        try {
            val config = service.fetchConfiguration(apiKey, storage.participantId)
            sdkConfig = config
            isConfigured = true
            if (UXRate.loggingEnabled) {
                Log.d(TAG, "SDK config refreshed (${config.surveys.size} surveys)")
            }
            evaluateAndShow()
        } catch (e: Exception) {
            if (UXRate.loggingEnabled) {
                Log.e(TAG, "Failed to refresh SDK config: ${e.message}")
            }
        }
    }

    /** Fire-and-forget wrapper used by the [localeOverride] setter. */
    private fun refetchConfiguration() {
        val apiKey = storedApiKey ?: return
        scope.launch { refreshConfig(apiKey) }
    }

    /**
     * Sets the current screen and re-evaluates trigger rules.
     * Maps to iOS SurveyManager.setCurrentScreen(_:)
     */
    fun setCurrentScreen(screenName: String) {
        val previousScreen = currentScreen
        currentScreen = screenName

        // Track screen event
        eventQueue?.enqueue(
            SdkEventItem(
                type = "screen",
                timestamp = SdkEventItem.nowTimestamp(),
                name = screenName
            )
        )

        // Increment visit count
        storage.incrementVisit(screenName)

        // Update replay capture screen name and check start/stop triggers
        replayCapture?.setCurrentScreen(screenName)
        replayCapture?.let { capture ->
            if (capture.shouldStop(forScreen = screenName)) {
                capture.stopCapturing()
                val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
                scope.launch(Dispatchers.IO) {
                    try { capture.flushBuffer(studyId) } catch (_: Exception) {}
                }
            } else if (capture.shouldCapture(forScreen = screenName)) {
                UXRate.currentActivity?.let { activity ->
                    capture.activateCapture(activity)
                }
            }
        }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Screen: $screenName (visits: ${storage.visitCount(screenName)}, configured: $isConfigured)")
        }

        // Only re-evaluate trigger rules when the screen actually changes.
        // This prevents duplicate impression events on recomposition or
        // re-navigation to the same screen.
        if (screenName != previousScreen) {
            evaluateAndShow()
        }
    }

    /**
     * Clears the current screen, hiding any visible banner.
     * Called when a composable with SurveyScreen() leaves composition.
     */
    fun clearScreen(screenName: String) {
        // Only clear if this screen is still the current one
        if (currentScreen == screenName) {
            currentScreen = null
            _shouldShowBanner.value = false

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Screen cleared: $screenName")
            }
        }
    }

    /**
     * Core trigger evaluation and display logic.
     * Maps to iOS SurveyManager.evaluateAndShow()
     */
    private fun evaluateAndShow() {
        // Guard: must be configured, have config, and have current screen
        if (!isConfigured) return
        val config = sdkConfig ?: return
        val screen = currentScreen ?: return

        // Guard: no chat already presented
        if (_isChatPresented.value) return

        // Check daily cap
        if (storage.todaySurveyCount() >= config.settings.maxSurveysPerDay) {
            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Daily survey cap reached")
            }
            return
        }

        // Get all matching surveys, then exclude studies the user has
        // dismissed or completed during this session.
        val matches = evaluator.matchingSurveys(screen, config, sessionSurveyCount)
            .filterNot { dismissedStudies.contains(it.surveyId) || completedStudies.contains(it.surveyId) }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Found ${matches.size} matching surveys for screen '$screen'")
        }

        // Apply overlap strategy
        val selectedSurvey = resolve(matches)

        if (selectedSurvey != null) {
            val callback = UXRate.onBannerWillShow
            if (callback != null) {
                // Ask consumer whether to show the banner.
                // Safety timeout: if completion is never called, default to show after 2 s.
                var completed = false
                val timeoutJob = scope.launch {
                    delay(2000)
                    if (!completed) {
                        completed = true
                        showBanner(config, selectedSurvey, screen)
                    }
                }
                callback(selectedSurvey.surveyId, screen) { shouldShow ->
                    if (!completed) {
                        completed = true
                        timeoutJob.cancel()
                        scope.launch(Dispatchers.Main) {
                            if (shouldShow) {
                                showBanner(config, selectedSurvey, screen)
                            } else if (UXRate.loggingEnabled) {
                                Log.d(TAG, "Banner suppressed by onBannerWillShow callback")
                            }
                        }
                    }
                }
            } else {
                showBanner(config, selectedSurvey, screen)
            }
        } else {
            _shouldShowBanner.value = false
        }
    }

    /**
     * Commits the banner-show state, tracks impression, and flushes replay.
     * Extracted so [evaluateAndShow] can gate it behind [UXRate.onBannerWillShow].
     */
    private fun showBanner(config: SDKConfig, survey: SurveyConfig, screen: String) {
        val previousSurveyId = _activeSurveyState.value?.surveyId
        _activeSurveyState.value = ActiveSurveyState(
            sdkConfig = config,
            activeSurvey = survey
        )
        _shouldShowBanner.value = true

        // Only track impression when a different survey is shown
        if (survey.surveyId != previousSurveyId) {
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "impression",
                    timestamp = SdkEventItem.nowTimestamp(),
                    studyId = survey.surveyId
                )
            )
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "track",
                    timestamp = SdkEventItem.nowTimestamp(),
                    name = "uxrate_banner_shown",
                    studyId = survey.surveyId
                )
            )
        }

        // Flush replay buffer when banner shows
        replayCapture?.let { capture ->
            scope.launch(Dispatchers.IO) {
                try {
                    capture.flushBuffer(survey.surveyId)
                } catch (e: Exception) {
                    if (UXRate.loggingEnabled) {
                        Log.e(TAG, "Replay: flush on banner show failed: ${e.message}")
                    }
                }
            }
        }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Showing banner for survey: ${survey.name}")
        }
    }

    /**
     * Resolves multiple matching surveys using the configured overlap strategy.
     * Maps to iOS SurveyManager.resolve(matches:)
     */
    private fun resolve(matches: List<SurveyConfig>): SurveyConfig? {
        if (matches.isEmpty()) return null

        return when (overlapStrategy) {
            OverlapStrategy.SHOW_FIRST -> matches.first()
            OverlapStrategy.SHOW_LAST -> matches.last()
            OverlapStrategy.SHOW_RANDOM -> matches.random()
            OverlapStrategy.SHOW_NONE -> if (matches.size == 1) matches.first() else null
        }
    }

    /**
     * Programmatically hides the banner without tracking a dismiss event.
     * Used for app-driven cleanup (e.g. navigation, state change).
     */
    fun hideBanner() {
        _shouldShowBanner.value = false
    }

    /**
     * Dismisses the banner for the current screen.
     * Maps to iOS SurveyManager.dismissBanner()
     */
    fun dismissBanner() {
        // Track dismiss event
        val surveyId = _activeSurveyState.value?.surveyId
        eventQueue?.enqueue(
            SdkEventItem(
                type = "dismiss",
                timestamp = SdkEventItem.nowTimestamp(),
                studyId = surveyId
            )
        )

        surveyId?.let { dismissedStudies.add(it) }
        _shouldShowBanner.value = false
    }

    /**
     * Opens the chat for the active survey.
     * Maps to iOS SurveyManager.openChat()
     */
    fun openChat() {
        val surveyState = _activeSurveyState.value ?: return

        // Flush pending events before creating interview
        eventQueue?.flush()

        // Record survey as shown
        storage.recordShown(surveyState.surveyId)
        storage.incrementTodaySurveyCount()
        sessionSurveyCount++

        // Reset chat state
        _shouldShowBanner.value = false
        _isChatCompleted.value = false
        _messages.value = emptyList()
        _isChatPresented.value = true

        // Flush replay buffer and stop recording before starting the interview
        val studyId = surveyState.surveyId
        replayCapture?.let { capture ->
            scope.launch(Dispatchers.IO) {
                try {
                    capture.flushBuffer(studyId)
                } catch (e: Exception) {
                    if (UXRate.loggingEnabled) {
                        Log.e(TAG, "Replay: flush before chat failed: ${e.message}")
                    }
                }
            }
            capture.stopCapturing()
        }

        // Track survey started lifecycle event
        eventQueue?.enqueue(
            SdkEventItem(
                type = "track",
                timestamp = SdkEventItem.nowTimestamp(),
                name = "uxrate_survey_started",
                studyId = studyId
            )
        )

        // Launch chat activity
        UXRate.launchChatActivity()

        // Fetch initial messages
        scope.launch {
            _isLoadingResponse.value = true
            try {
                val initialMessages = service.createSession()
                val chatMessages = initialMessages.map { content ->
                    ChatMessage(
                        content = content,
                        role = ChatMessage.Role.ASSISTANT
                    )
                }
                _messages.value = chatMessages
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to create chat session: ${e.message}")
                }
                _messages.value = listOf(
                    ChatMessage(
                        content = "Sorry, we couldn't start the survey. Please try again later.",
                        role = ChatMessage.Role.ASSISTANT
                    )
                )
            } finally {
                _isLoadingResponse.value = false
            }
        }
    }

    /**
     * Sends a user message and handles the AI reply.
     * Maps to iOS SurveyManager.sendMessage(text:)
     */
    fun sendMessage(text: String) {
        val userMessage = ChatMessage(
            content = text,
            role = ChatMessage.Role.USER
        )
        _messages.value = _messages.value + userMessage
        _isLoadingResponse.value = true

        scope.launch {
            try {
                val reply = service.sendMessage(text, _messages.value)
                val assistantMessage = ChatMessage(
                    content = reply.content,
                    role = ChatMessage.Role.ASSISTANT
                )
                _messages.value = _messages.value + assistantMessage

                if (reply.isCompleted) {
                    val surveyId = _activeSurveyState.value?.surveyId
                    if (surveyId != null) {
                        storage.recordCompleted(surveyId)
                        // Prevent the just-completed study from re-triggering
                        // this session regardless of server-sent maxPerUser.
                        completedStudies.add(surveyId)
                    }
                    _isChatCompleted.value = true
                }
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to send message: ${e.message}")
                }
                val errorMessage = ChatMessage(
                    content = "Sorry, something went wrong. Please try again.",
                    role = ChatMessage.Role.ASSISTANT
                )
                _messages.value = _messages.value + errorMessage
            } finally {
                _isLoadingResponse.value = false
            }
        }
    }

    /**
     * Called when chat is dismissed (by user or system).
     */
    fun onChatDismissed() {
        val surveyId = _activeSurveyState.value?.surveyId

        if (!_isChatCompleted.value) {
            // Track cancel event if chat was not completed
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "cancel",
                    timestamp = SdkEventItem.nowTimestamp(),
                    studyId = surveyId
                )
            )

            // Track survey closed lifecycle event
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "track",
                    timestamp = SdkEventItem.nowTimestamp(),
                    name = "uxrate_survey_closed",
                    studyId = surveyId
                )
            )
        } else {
            // Track survey completed lifecycle event
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "track",
                    timestamp = SdkEventItem.nowTimestamp(),
                    name = "uxrate_survey_completed",
                    studyId = surveyId
                )
            )
        }

        _isChatPresented.value = false
    }

    /**
     * Stores user identification info for segment targeting.
     * Maps to iOS SurveyManager.identify(userId:properties:)
     */
    fun identify(userId: String, properties: Map<String, String>) {
        storage.setUserId(userId)
        if (properties.isNotEmpty()) {
            storage.setUserProperties(properties)
        }

        // Track identify event
        @Suppress("UNCHECKED_CAST")
        eventQueue?.enqueue(
            SdkEventItem(
                type = "identify",
                timestamp = SdkEventItem.nowTimestamp(),
                name = userId,
                properties = properties as? Map<String, Any>
            )
        )
    }

    /**
     * Tracks a custom event and re-evaluates trigger rules.
     * Maps to iOS SurveyManager.track(event:properties:)
     */
    /**
     * Flushes replay buffer without stopping capture.
     * Called when the app enters background — recording resumes on foreground.
     */
    fun flushReplay() {
        replayCapture?.let { capture ->
            val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
            scope.launch(Dispatchers.IO) {
                try { capture.flushBuffer(studyId) } catch (_: Exception) {}
            }
        }
    }

    fun track(event: String, properties: Map<String, String>) {
        storage.incrementEvent(event)

        // Track event
        @Suppress("UNCHECKED_CAST")
        eventQueue?.enqueue(
            SdkEventItem(
                type = "track",
                timestamp = SdkEventItem.nowTimestamp(),
                name = event,
                properties = if (properties.isNotEmpty()) properties as Map<String, Any> else null
            )
        )

        // Check replay start/stop triggers for this event
        replayCapture?.let { capture ->
            if (capture.shouldStop(forEvent = event)) {
                capture.stopCapturing()
                val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
                scope.launch(Dispatchers.IO) {
                    try { capture.flushBuffer(studyId) } catch (_: Exception) {}
                }
            } else if (capture.shouldCapture(forEvent = event)) {
                UXRate.currentActivity?.let { activity ->
                    capture.activateCapture(activity)
                }
            }
        }

        evaluateAndShow()
    }
}
