package com.uxrate.sdk.models

import com.uxrate.sdk.services.ReplayConfig
import java.util.Date

// MARK: - Public Enums

/**
 * Banner display position on screen.
 * Maps to iOS BannerPosition enum.
 */
enum class BannerPosition {
    /** Banner at top of screen */
    HEADER,
    /** Banner at bottom of screen (default) */
    NAVIGATION;

    companion object {
        fun from(value: String?): BannerPosition {
            return when (value?.lowercase()) {
                "header" -> HEADER
                "navigation" -> NAVIGATION
                else -> NAVIGATION
            }
        }
    }
}

/**
 * SDK color scheme theme.
 * Maps to iOS SDKTheme enum.
 */
enum class SDKTheme {
    /** Follow device/system setting */
    AUTO,
    /** Force light appearance */
    LIGHT,
    /** Force dark appearance */
    DARK;

    companion object {
        fun from(value: String?): SDKTheme {
            return when (value?.lowercase()) {
                "light" -> LIGHT
                "dark" -> DARK
                "auto" -> AUTO
                else -> AUTO
            }
        }
    }
}

/**
 * Strategy for resolving multiple matching surveys.
 * Maps to iOS OverlapStrategy enum.
 */
enum class OverlapStrategy {
    /** Show first matching survey in config array order (default) */
    SHOW_FIRST,
    /** Show last matching survey */
    SHOW_LAST,
    /** Randomly pick one from matching surveys */
    SHOW_RANDOM,
    /** Show nothing if multiple surveys match */
    SHOW_NONE;

    companion object {
        fun from(value: String?): OverlapStrategy {
            return when (value?.lowercase()) {
                "showfirst" -> SHOW_FIRST
                "showlast" -> SHOW_LAST
                "showrandom" -> SHOW_RANDOM
                "shownone" -> SHOW_NONE
                else -> SHOW_FIRST
            }
        }
    }
}

// MARK: - CodableValue (flexible JSON scalar)

/**
 * Represents a flexible JSON scalar value.
 * Maps to iOS CodableValue enum.
 */
sealed class CodableValue {
    data class StringValue(val value: String) : CodableValue()
    data class IntValue(val value: Int) : CodableValue()
    data class DoubleValue(val value: Double) : CodableValue()
    data class BoolValue(val value: Boolean) : CodableValue()

    val stringValue: String?
        get() = (this as? StringValue)?.value

    val intValue: Int?
        get() = (this as? IntValue)?.value

    val doubleValue: Double?
        get() = when (this) {
            is DoubleValue -> value
            is IntValue -> value.toDouble()
            else -> null
        }

    val boolValue: Boolean?
        get() = (this as? BoolValue)?.value
}

// MARK: - SDK Config Models

data class SDKConfig(
    val surveys: List<SurveyConfig>,
    val settings: GlobalSettings,
    val cacheExpiresAt: Date
)

data class SurveyConfig(
    val surveyId: String,
    val name: String,
    val triggers: List<TriggerRule>,
    val triggerLogic: String, // Currently always "AND"
    val frequency: FrequencyConfig,
    val appearance: AppearanceConfig,
    val replayConfig: ReplayConfig? = null,
    // Higher priority wins when multiple studies match the same screen.
    // Defaults to 0 if the server doesn't send one.
    val priority: Int = 0
)

data class TriggerRule(
    val type: String,
    val conditions: Map<String, CodableValue>
)

data class FrequencyConfig(
    val maxPerUser: Int,
    val cooldownDays: Int,
    val maxPerSession: Int
)

data class AppearanceConfig(
    val headline: String,
    val subtext: String,
    val callToAction: String,
    val position: BannerPosition
)

data class GlobalSettings(
    val maxSurveysPerDay: Int
)

// MARK: - Active Survey State

data class ActiveSurveyState(
    val sdkConfig: SDKConfig,
    val activeSurvey: SurveyConfig
) {
    val headline: String get() = activeSurvey.appearance.headline
    val subtext: String get() = activeSurvey.appearance.subtext
    val callToAction: String get() = activeSurvey.appearance.callToAction
    val position: BannerPosition get() = activeSurvey.appearance.position
    val surveyId: String get() = activeSurvey.surveyId
}
