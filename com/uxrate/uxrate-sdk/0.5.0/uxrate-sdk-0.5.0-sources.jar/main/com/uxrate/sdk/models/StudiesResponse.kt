package com.uxrate.sdk.models

import com.uxrate.sdk.services.ReplayConfig
import org.json.JSONArray
import org.json.JSONObject

/**
 * Wire format models for /api/sdk/init response.
 * Maps to iOS StudiesResponse and related Decodable structs.
 * Uses org.json manual parsing instead of Codable.
 */

data class StudiesResponse(
    val studies: List<Study>
) {
    companion object {
        fun fromJson(json: JSONObject): StudiesResponse {
            val studiesArray = json.optJSONArray("studies") ?: JSONArray()
            val studies = mutableListOf<Study>()
            for (i in 0 until studiesArray.length()) {
                studies.add(Study.fromJson(studiesArray.getJSONObject(i)))
            }
            return StudiesResponse(studies)
        }
    }
}

data class Study(
    val id: String,
    val name: String,
    val isActive: Boolean,
    val platform: String,
    val priority: Int,
    val appearance: StudyAppearance,
    val targetTrigger: TargetTrigger?,
    val replayConfig: ReplayConfig? = null
) {
    companion object {
        fun fromJson(json: JSONObject): Study {
            return Study(
                id = json.getString("id"),
                name = json.getString("name"),
                isActive = json.optBoolean("isActive", false),
                platform = json.optString("platform", ""),
                priority = json.optInt("priority", 0),
                appearance = StudyAppearance.fromJson(json.getJSONObject("appearance")),
                targetTrigger = json.optJSONObject("targetTrigger")?.let {
                    TargetTrigger.fromJson(it)
                },
                replayConfig = json.optJSONObject("replayConfig")?.let {
                    ReplayConfig.fromJson(it)
                }
            )
        }
    }
}

data class StudyAppearance(
    val headline: String,
    val subtext: String,
    val callToAction: String,
    val position: String?
) {
    companion object {
        fun fromJson(json: JSONObject): StudyAppearance {
            return StudyAppearance(
                headline = json.optString("headline", ""),
                subtext = json.optString("subtext", ""),
                callToAction = json.optString("callToAction", ""),
                position = json.optString("position", "navigation").takeIf { it.isNotEmpty() }
            )
        }
    }
}

data class TargetTrigger(
    val screens: List<ScreenTarget>,
    val events: List<EventTarget>
) {
    companion object {
        fun fromJson(json: JSONObject): TargetTrigger {
            val screensArray = json.optJSONArray("screens") ?: JSONArray()
            val screens = mutableListOf<ScreenTarget>()
            for (i in 0 until screensArray.length()) {
                screens.add(ScreenTarget.fromJson(screensArray.getJSONObject(i)))
            }

            val eventsArray = json.optJSONArray("events") ?: JSONArray()
            val events = mutableListOf<EventTarget>()
            for (i in 0 until eventsArray.length()) {
                events.add(EventTarget.fromJson(eventsArray.getJSONObject(i)))
            }

            return TargetTrigger(screens, events)
        }
    }
}

data class ScreenTarget(
    val id: String?,
    val value: String,
    val matchType: String
) {
    companion object {
        fun fromJson(json: JSONObject): ScreenTarget {
            return ScreenTarget(
                id = if (json.has("id")) json.optString("id") else null,
                value = json.optString("value", ""),
                matchType = json.optString("matchType", "name")
            )
        }
    }
}

data class EventTarget(
    val id: String?,
    val eventName: String,
    val operator: String, // "is" | "fired_gte" | "fired_exactly"
    val value: String?
) {
    companion object {
        fun fromJson(json: JSONObject): EventTarget {
            return EventTarget(
                id = if (json.has("id")) json.optString("id") else null,
                eventName = json.optString("eventName", ""),
                operator = json.optString("operator", "is"),
                value = if (json.has("value")) json.optString("value") else null
            )
        }
    }
}
