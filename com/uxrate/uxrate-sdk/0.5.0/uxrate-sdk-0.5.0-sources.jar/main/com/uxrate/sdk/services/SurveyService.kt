package com.uxrate.sdk.services

import com.uxrate.sdk.models.ChatMessage
import com.uxrate.sdk.models.ChatReply
import com.uxrate.sdk.models.SDKConfig
import org.json.JSONObject

/**
 * Interface for survey service implementations.
 * Maps to iOS SurveyServiceProtocol.
 */
interface SurveyService {

    /**
     * Fetches full SDK configuration from the backend.
     * @param apiKey The SDK API key (uxr_* token)
     * @param participantId The device-scoped participant UUID; sent to the
     *   server so completed one-shot studies can be excluded from the response.
     * @return SDKConfig with all surveys, triggers, and appearance settings
     */
    suspend fun fetchConfiguration(apiKey: String, participantId: String): SDKConfig

    /**
     * Creates an interview session on the backend and fetches initial AI messages.
     * @return List of AI opening message strings in order
     */
    suspend fun createSession(): List<String>

    /**
     * Sends a user message and returns the AI reply.
     * @param message The user's message text
     * @param conversationHistory Full conversation history for context
     * @return ChatReply with AI response content and isCompleted flag
     */
    suspend fun sendMessage(message: String, conversationHistory: List<ChatMessage>): ChatReply

    /**
     * Sends batched SDK events to the backend.
     * @param participantId The participant's unique ID
     * @param events List of SDK event items to send
     */
    suspend fun sendEvents(participantId: String, events: List<SdkEventItem>)

    /**
     * Uploads session replay frames to the backend.
     * @param participantId The participant identifier
     * @param metadata JSON metadata about the replay session
     * @param frames List of captured replay frames
     */
    suspend fun uploadReplayFrames(
        participantId: String,
        metadata: JSONObject,
        frames: List<ReplayFrame>
    )
}
