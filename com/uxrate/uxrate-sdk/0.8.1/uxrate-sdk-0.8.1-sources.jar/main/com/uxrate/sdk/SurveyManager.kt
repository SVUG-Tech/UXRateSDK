package com.uxrate.sdk

import android.util.Log
import com.uxrate.sdk.models.*
import com.uxrate.sdk.services.EventQueue
import com.uxrate.sdk.services.LiveSurveyService
import com.uxrate.sdk.services.LocalStorage
import com.uxrate.sdk.services.SdkEventItem
import com.uxrate.sdk.services.ReplayCapture
import com.uxrate.sdk.services.SurveyService
import com.uxrate.sdk.services.TriggerEvaluator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Central state manager for the UXRate SDK.
 * Maps to iOS SurveyManager (@Observable class).
 *
 * Uses MutableStateFlow for reactive state (equivalent to SwiftUI @Observable).
 * All state mutations dispatched on Main thread.
 */
class SurveyManager(
    private val service: SurveyService,
    val storage: LocalStorage,
    val overlapStrategy: OverlapStrategy,
    val theme: SDKTheme,
    internal val eventQueue: EventQueue? = null,
    val baseURL: String = "https://app.uxrate.com"
) {
    companion object {
        private const val TAG = "UXRate"
    }

    // Coroutine scope for async operations
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // MARK: - Configuration State

    private var isConfigured = false
    private var sdkConfig: SDKConfig? = null

    // MARK: - Locale

    /** Locale override set via UXRate.setLocale(). Null = use device locale. */
    var localeOverride: java.util.Locale? = null
        set(value) {
            field = value
            (service as? com.uxrate.sdk.services.LiveSurveyService)?.localeOverride = value
            if (isConfigured) refetchConfiguration()
        }

    /** Stored API key for re-fetching config on locale change. */
    private var storedApiKey: String? = null

    // MARK: - Screen Tracking

    private var currentScreen: String? = null
    var pendingManualScreen: String? = null

    // MARK: - Survey State

    private val _activeSurveyState = MutableStateFlow<ActiveSurveyState?>(null)
    val activeSurveyState: StateFlow<ActiveSurveyState?> = _activeSurveyState.asStateFlow()

    private val _shouldShowBanner = MutableStateFlow(false)
    val shouldShowBanner: StateFlow<Boolean> = _shouldShowBanner.asStateFlow()

    // Session-only guards. Keyed by surveyId so dismissing on screen A also
    // prevents the same study from re-showing on screen B (see Android#13).
    // Completion set mirrors server-side filtering until it lands (see
    // uxrate#136) — defends against stale cached configs.
    private val dismissedStudies = mutableSetOf<String>()
    private val completedStudies = mutableSetOf<String>()

    /** Session counters used by Target & Trigger caps with scope = SESSION.
     *  All buckets reset on [configure]. */
    private val sessionCapCounts = mutableMapOf<String, MutableMap<CapEvent, Int>>()

    /** Cumulative count of each tracked event since [configure]. Drives
     *  `EventRule.scope == "session"` evaluation. */
    private val sessionEventCount = mutableMapOf<String, Int>()

    /** Per-screen event counts. Cleared for the previous screen whenever
     *  [setCurrentScreen] is called with a different name. Drives
     *  `EventRule.scope == "on_screen"` evaluation. */
    private val onScreenEventCount = mutableMapOf<String, MutableMap<String, Int>>()

    private val countSource = TriggerEvaluator.CountSource { eventName, scope, screen ->
        when (scope) {
            "on_screen" -> onScreenEventCount[screen]?.get(eventName) ?: 0
            else -> sessionEventCount[eventName] ?: 0
        }
    }

    // MARK: - Chat State

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoadingResponse = MutableStateFlow(false)
    val isLoadingResponse: StateFlow<Boolean> = _isLoadingResponse.asStateFlow()

    private val _isChatCompleted = MutableStateFlow(false)
    val isChatCompleted: StateFlow<Boolean> = _isChatCompleted.asStateFlow()

    /**
     * Set when `service.createSession()` throws so the chat UI can swap the
     * input bar for a single "Close" button instead of accepting messages
     * the backend already refused to accept.
     */
    private val _isChatErrored = MutableStateFlow(false)
    val isChatErrored: StateFlow<Boolean> = _isChatErrored.asStateFlow()

    private val _isChatPresented = MutableStateFlow(false)
    val isChatPresented: StateFlow<Boolean> = _isChatPresented.asStateFlow()

    // MARK: - Frequency Tracking

    private var sessionSurveyCount = 0
    private val evaluator = TriggerEvaluator(storage)

    // MARK: - Replay

    var replayCapture: ReplayCapture? = null
    private var fallbackStudyId: String? = null

    // MARK: - Core Methods

    /**
     * Fetches configuration from the backend and marks SDK as configured.
     * Maps to iOS SurveyManager.configure(apiKey:)
     */
    suspend fun configure(apiKey: String) {
        storedApiKey = apiKey
        sessionSurveyCount = 0
        dismissedStudies.clear()
        completedStudies.clear()
        sessionCapCounts.clear()
        sessionEventCount.clear()
        onScreenEventCount.clear()

        try {
            val config = service.fetchConfiguration(apiKey, storage.participantId)
            sdkConfig = config
            isConfigured = true

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "SDK configured with ${config.surveys.size} surveys")
            }

            // Initialize replay capture if any survey has replay config enabled
            val firstReplayConfig = config.surveys
                .mapNotNull { it.replayConfig }
                .firstOrNull { it.scope != "off" }

            if (firstReplayConfig != null) {
                val capture = ReplayCapture(baseURL = baseURL, apiKey = apiKey)
                capture.configure(firstReplayConfig, storage.participantId)

                // Wire the periodic flush handler
                capture.flushHandler = { cap ->
                    val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
                    scope.launch(Dispatchers.IO) {
                        try { cap.flushBuffer(studyId) } catch (_: Exception) {}
                    }
                }

                // Store fallback studyId for flushes when no active survey
                fallbackStudyId = config.surveys.firstOrNull()?.surveyId

                replayCapture = capture

                if (UXRate.loggingEnabled) {
                    Log.d(TAG, "Replay configured: scope=${firstReplayConfig.scope}, trigger=${firstReplayConfig.trigger}, armed=${firstReplayConfig.trigger == "triggered"}")
                }
            }

            // Evaluate in case screen tracking already fired before config was ready
            evaluateAndShow()
        } catch (e: Exception) {
            if (UXRate.loggingEnabled) {
                Log.e(TAG, "Failed to configure SDK: ${e.message}")
            }
        }
    }

    /**
     * Re-fetches the SDK configuration without touching session state.
     * Unlike [configure], this does NOT reset `sessionSurveyCount` or
     * clear dismissed/completed guards — so an admin config edit (or a
     * locale change) doesn't undo the host app's session-level frequency
     * tracking.
     *
     * Triggers a fresh `evaluateAndShow()` so a newly-activated study can
     * surface on the current screen immediately.
     */
    suspend fun refreshConfig(apiKey: String) {
        try {
            val config = service.fetchConfiguration(apiKey, storage.participantId)
            sdkConfig = config
            isConfigured = true
            if (UXRate.loggingEnabled) {
                Log.d(TAG, "SDK config refreshed (${config.surveys.size} surveys)")
            }
            evaluateAndShow()
        } catch (e: Exception) {
            if (UXRate.loggingEnabled) {
                Log.e(TAG, "Failed to refresh SDK config: ${e.message}")
            }
        }
    }

    /** Fire-and-forget wrapper used by the [localeOverride] setter. */
    private fun refetchConfiguration() {
        val apiKey = storedApiKey ?: return
        scope.launch { refreshConfig(apiKey) }
    }

    /**
     * Sets the current screen and re-evaluates trigger rules.
     * Maps to iOS SurveyManager.setCurrentScreen(_:)
     */
    fun setCurrentScreen(screenName: String) {
        val previousScreen = currentScreen
        // Drop the previous screen's `on_screen` counter the moment the screen
        // name changes — matches the spec (`on_screen` resets on screen
        // *name* change, not per-trigger).
        if (previousScreen != null && previousScreen != screenName) {
            onScreenEventCount.remove(previousScreen)
        }
        currentScreen = screenName

        // Track screen event
        eventQueue?.enqueue(
            SdkEventItem(
                type = "screen",
                timestamp = SdkEventItem.nowTimestamp(),
                name = screenName
            )
        )

        // Increment visit count
        storage.incrementVisit(screenName)

        // Update replay capture screen name and check start/stop triggers
        replayCapture?.setCurrentScreen(screenName)
        replayCapture?.let { capture ->
            if (capture.shouldStop(forScreen = screenName)) {
                capture.stopCapturing()
                val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
                scope.launch(Dispatchers.IO) {
                    try { capture.flushBuffer(studyId) } catch (_: Exception) {}
                }
            } else if (capture.shouldCapture(forScreen = screenName)) {
                UXRate.currentActivity?.let { activity ->
                    capture.activateCapture(activity)
                }
            }
        }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Screen: $screenName (visits: ${storage.visitCount(screenName)}, configured: $isConfigured)")
        }

        // Only re-evaluate trigger rules when the screen actually changes.
        // This prevents duplicate impression events on recomposition or
        // re-navigation to the same screen.
        if (screenName != previousScreen) {
            evaluateAndShow()
        }
    }

    /**
     * Clears the current screen, hiding any visible banner.
     * Called when a composable with SurveyScreen() leaves composition.
     */
    fun clearScreen(screenName: String) {
        // Only clear if this screen is still the current one
        if (currentScreen == screenName) {
            currentScreen = null
            _shouldShowBanner.value = false

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Screen cleared: $screenName")
            }
        }
    }

    /**
     * Core trigger evaluation and display logic.
     * Maps to iOS SurveyManager.evaluateAndShow()
     */
    private fun evaluateAndShow() {
        // Guard: must be configured, have config, and have current screen
        if (!isConfigured) return
        val config = sdkConfig ?: return
        val screen = currentScreen ?: return

        // Guard: no chat already presented
        if (_isChatPresented.value) return

        // Check daily cap
        if (storage.todaySurveyCount() >= config.settings.maxSurveysPerDay) {
            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Daily survey cap reached")
            }
            return
        }

        // Get all matching surveys, then exclude studies the user has
        // dismissed or completed during this session.
        val matches = evaluator.matchingSurveys(screen, config, sessionSurveyCount, countSource)
            // Per-event Target & Trigger caps. `capReached` consults both
            // in-memory session buckets and persistent day/user buckets so
            // a study that has exhausted any of its four caps never
            // surfaces a banner — avoiding the 409 round-trip on chat open.
            .filter { survey ->
                // Unconditional completion gate. `recordCompleted` is fired
                // by the chat flow on `reply.isCompleted == true` AND by the
                // 409 `already_participated` branch in `openChat` — either
                // way, once the persistent counter is non-zero this study
                // never re-banners on this device.
                if (storage.completedCount(survey.surveyId) > 0) return@filter false
                if (dismissedStudies.contains(survey.surveyId)) return@filter false
                CapEvent.values().none { event -> capReached(survey, event) }
            }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Found ${matches.size} matching surveys for screen '$screen'")
        }

        // Apply overlap strategy
        val selectedSurvey = resolve(matches)

        if (selectedSurvey != null) {
            val callback = UXRate.onBannerWillShow
            if (callback != null) {
                // Ask consumer whether to show the banner.
                // Safety timeout: if completion is never called, default to show after 2 s.
                var completed = false
                val timeoutJob = scope.launch {
                    delay(2000)
                    if (!completed) {
                        completed = true
                        showBanner(config, selectedSurvey, screen)
                    }
                }
                callback(selectedSurvey.surveyId, screen) { shouldShow ->
                    if (!completed) {
                        completed = true
                        timeoutJob.cancel()
                        scope.launch(Dispatchers.Main) {
                            if (shouldShow) {
                                showBanner(config, selectedSurvey, screen)
                            } else if (UXRate.loggingEnabled) {
                                Log.d(TAG, "Banner suppressed by onBannerWillShow callback")
                            }
                        }
                    }
                }
            } else {
                showBanner(config, selectedSurvey, screen)
            }
        } else {
            _shouldShowBanner.value = false
        }
    }

    /**
     * Commits the banner-show state, tracks impression, and flushes replay.
     * Extracted so [evaluateAndShow] can gate it behind [UXRate.onBannerWillShow].
     */
    private fun showBanner(config: SDKConfig, survey: SurveyConfig, screen: String) {
        val previousSurveyId = _activeSurveyState.value?.surveyId
        _activeSurveyState.value = ActiveSurveyState(
            sdkConfig = config,
            activeSurvey = survey
        )
        _shouldShowBanner.value = true

        // Only track impression when a different survey is shown
        if (survey.surveyId != previousSurveyId) {
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "impression",
                    timestamp = SdkEventItem.nowTimestamp(),
                    studyId = survey.surveyId
                )
            )
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "track",
                    timestamp = SdkEventItem.nowTimestamp(),
                    name = "uxrate_banner_shown",
                    studyId = survey.surveyId
                )
            )
            recordCapEvent(survey.surveyId, CapEvent.BANNER_SHOWN)
        }

        // Flush replay buffer when banner shows
        replayCapture?.let { capture ->
            scope.launch(Dispatchers.IO) {
                try {
                    capture.flushBuffer(survey.surveyId)
                } catch (e: Exception) {
                    if (UXRate.loggingEnabled) {
                        Log.e(TAG, "Replay: flush on banner show failed: ${e.message}")
                    }
                }
            }
        }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Showing banner for survey: ${survey.name}")
        }
    }

    /**
     * Resolves multiple matching surveys using the configured overlap strategy.
     * Maps to iOS SurveyManager.resolve(matches:)
     */
    private fun resolve(matches: List<SurveyConfig>): SurveyConfig? {
        if (matches.isEmpty()) return null

        return when (overlapStrategy) {
            OverlapStrategy.SHOW_FIRST -> matches.first()
            OverlapStrategy.SHOW_LAST -> matches.last()
            OverlapStrategy.SHOW_RANDOM -> matches.random()
            OverlapStrategy.SHOW_NONE -> if (matches.size == 1) matches.first() else null
        }
    }

    /**
     * Programmatically hides the banner without tracking a dismiss event.
     * Used for app-driven cleanup (e.g. navigation, state change).
     */
    fun hideBanner() {
        _shouldShowBanner.value = false
    }

    /**
     * Dismisses the banner for the current screen.
     * Maps to iOS SurveyManager.dismissBanner()
     */
    fun dismissBanner() {
        // Track dismiss event
        val surveyId = _activeSurveyState.value?.surveyId
        eventQueue?.enqueue(
            SdkEventItem(
                type = "dismiss",
                timestamp = SdkEventItem.nowTimestamp(),
                studyId = surveyId
            )
        )

        surveyId?.let {
            dismissedStudies.add(it)
            recordCapEvent(it, CapEvent.BANNER_DISMISSED)
        }
        _shouldShowBanner.value = false
    }

    /**
     * Opens the chat for the active survey.
     * Maps to iOS SurveyManager.openChat()
     */
    fun openChat() {
        val surveyState = _activeSurveyState.value ?: return

        // Flush pending events before creating interview
        eventQueue?.flush()

        // Record survey as shown
        storage.recordShown(surveyState.surveyId)
        storage.incrementTodaySurveyCount()
        sessionSurveyCount++

        // Reset chat state
        _shouldShowBanner.value = false
        _isChatCompleted.value = false
        _isChatErrored.value = false
        _messages.value = emptyList()
        _isChatPresented.value = true

        // Flush replay buffer and stop recording before starting the interview
        val studyId = surveyState.surveyId
        replayCapture?.let { capture ->
            scope.launch(Dispatchers.IO) {
                try {
                    capture.flushBuffer(studyId)
                } catch (e: Exception) {
                    if (UXRate.loggingEnabled) {
                        Log.e(TAG, "Replay: flush before chat failed: ${e.message}")
                    }
                }
            }
            capture.stopCapturing()
        }

        // Track survey started lifecycle event
        eventQueue?.enqueue(
            SdkEventItem(
                type = "track",
                timestamp = SdkEventItem.nowTimestamp(),
                name = "uxrate_survey_started",
                studyId = studyId
            )
        )
        recordCapEvent(studyId, CapEvent.SURVEY_STARTED)

        // Launch chat activity
        UXRate.launchChatActivity()

        // Fetch initial messages
        scope.launch {
            _isLoadingResponse.value = true
            _isChatErrored.value = false
            try {
                val seedMessages = service.createSession()
                _messages.value = seedMessages.map { seed ->
                    ChatMessage(
                        content = seed.content,
                        role = if (seed.isParticipant)
                            ChatMessage.Role.USER
                        else
                            ChatMessage.Role.ASSISTANT
                    )
                }
            } catch (e: LiveSurveyService.LiveSurveyError.AlreadyParticipated) {
                // Server says this participant already completed the study.
                // Treat as a clean terminal state: drop a friendly message
                // and lock the cap counters so the banner never re-fires
                // for this study on this device. The "Return to app" CTA
                // takes the place of the input bar because isChatCompleted
                // is true.
                if (UXRate.loggingEnabled) {
                    Log.d(TAG, "createSession blocked by already_participated")
                }
                storage.recordCompleted(studyId)
                completedStudies.add(studyId)
                recordCapEvent(studyId, CapEvent.SURVEY_COMPLETED)
                _messages.value = listOf(
                    ChatMessage(
                        content = "Thanks — you've already completed this study.",
                        role = ChatMessage.Role.ASSISTANT
                    )
                )
                _isChatCompleted.value = true
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to create chat session: ${e.message}")
                }
                _messages.value = listOf(
                    ChatMessage(
                        content = "Sorry, we couldn't start the survey. Please try again later.",
                        role = ChatMessage.Role.ASSISTANT
                    )
                )
                // Lock the input bar so the user isn't invited to type into
                // a chat the server already refused to start.
                _isChatErrored.value = true
            } finally {
                _isLoadingResponse.value = false
            }
        }
    }

    /**
     * Sends a user message and handles the AI reply.
     * Maps to iOS SurveyManager.sendMessage(text:)
     */
    fun sendMessage(text: String) {
        val userMessage = ChatMessage(
            content = text,
            role = ChatMessage.Role.USER
        )
        _messages.value = _messages.value + userMessage
        _isLoadingResponse.value = true

        scope.launch {
            try {
                val reply = service.sendMessage(text, _messages.value)
                val assistantMessage = ChatMessage(
                    content = reply.content,
                    role = ChatMessage.Role.ASSISTANT
                )
                _messages.value = _messages.value + assistantMessage

                if (reply.isCompleted) {
                    val surveyId = _activeSurveyState.value?.surveyId
                    if (surveyId != null) {
                        storage.recordCompleted(surveyId)
                        // Prevent the just-completed study from re-triggering
                        // this session regardless of server-sent maxPerUser.
                        completedStudies.add(surveyId)
                        recordCapEvent(surveyId, CapEvent.SURVEY_COMPLETED)
                    }
                    _isChatCompleted.value = true
                }
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to send message: ${e.message}")
                }
                val errorMessage = ChatMessage(
                    content = "Sorry, something went wrong. Please try again.",
                    role = ChatMessage.Role.ASSISTANT
                )
                _messages.value = _messages.value + errorMessage
            } finally {
                _isLoadingResponse.value = false
            }
        }
    }

    /**
     * Called when chat is dismissed (by user or system).
     */
    fun onChatDismissed() {
        val surveyId = _activeSurveyState.value?.surveyId

        if (!_isChatCompleted.value) {
            // Track cancel event if chat was not completed
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "cancel",
                    timestamp = SdkEventItem.nowTimestamp(),
                    studyId = surveyId
                )
            )

            // Track survey closed lifecycle event
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "track",
                    timestamp = SdkEventItem.nowTimestamp(),
                    name = "uxrate_survey_closed",
                    studyId = surveyId
                )
            )
        } else {
            // Track survey completed lifecycle event
            eventQueue?.enqueue(
                SdkEventItem(
                    type = "track",
                    timestamp = SdkEventItem.nowTimestamp(),
                    name = "uxrate_survey_completed",
                    studyId = surveyId
                )
            )
        }

        _isChatPresented.value = false
    }

    /**
     * Stores user identification info for segment targeting.
     * Maps to iOS SurveyManager.identify(userId:properties:)
     */
    fun identify(userId: String, properties: Map<String, String>) {
        storage.setUserId(userId)
        if (properties.isNotEmpty()) {
            storage.setUserProperties(properties)
        }

        // Track identify event
        @Suppress("UNCHECKED_CAST")
        eventQueue?.enqueue(
            SdkEventItem(
                type = "identify",
                timestamp = SdkEventItem.nowTimestamp(),
                name = userId,
                properties = properties as? Map<String, Any>
            )
        )
    }

    /**
     * Tracks a custom event and re-evaluates trigger rules.
     * Maps to iOS SurveyManager.track(event:properties:)
     */
    /**
     * Flushes replay buffer without stopping capture.
     * Called when the app enters background — recording resumes on foreground.
     */
    fun flushReplay() {
        replayCapture?.let { capture ->
            val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
            scope.launch(Dispatchers.IO) {
                try { capture.flushBuffer(studyId) } catch (_: Exception) {}
            }
        }
    }

    fun track(event: String, properties: Map<String, String>) {
        // Trim whitespace so "tap_go_to_settings " in the host app still
        // matches a dashboard-configured "tap_go_to_settings" trigger.
        val event = event.trim()
        if (event.isEmpty()) return

        storage.incrementEvent(event)

        // PR 3 in-memory counters. `storage.incrementEvent` stays for replay
        // capture (`shouldStop`/`shouldCapture`); these are evaluator-only.
        sessionEventCount[event] = (sessionEventCount[event] ?: 0) + 1
        currentScreen?.let { screen ->
            val perScreen = onScreenEventCount.getOrPut(screen) { mutableMapOf() }
            perScreen[event] = (perScreen[event] ?: 0) + 1
        }

        // Track event
        @Suppress("UNCHECKED_CAST")
        eventQueue?.enqueue(
            SdkEventItem(
                type = "track",
                timestamp = SdkEventItem.nowTimestamp(),
                name = event,
                properties = if (properties.isNotEmpty()) properties as Map<String, Any> else null
            )
        )

        // Check replay start/stop triggers for this event
        replayCapture?.let { capture ->
            if (capture.shouldStop(forEvent = event)) {
                capture.stopCapturing()
                val studyId = _activeSurveyState.value?.surveyId ?: fallbackStudyId
                scope.launch(Dispatchers.IO) {
                    try { capture.flushBuffer(studyId) } catch (_: Exception) {}
                }
            } else if (capture.shouldCapture(forEvent = event)) {
                UXRate.currentActivity?.let { activity ->
                    capture.activateCapture(activity)
                }
            }
        }

        evaluateAndShow()
    }

    // MARK: - Target & Trigger caps

    /** Returns true when the survey's cap for [event] has been reached and
     *  the banner/chat should be suppressed. SESSION scope reads the
     *  in-memory [sessionCapCounts]; USER / DAY scopes read the
     *  persistent counters in [LocalStorage]. */
    private fun capReached(survey: SurveyConfig, event: CapEvent): Boolean {
        val cap = survey.caps.entry(event) ?: return false
        val count = currentCapCount(survey.surveyId, event, cap.scope)
        return count >= cap.max
    }

    private fun currentCapCount(surveyId: String, event: CapEvent, scope: CapScope): Int =
        when (scope) {
            CapScope.SESSION -> sessionCapCounts[surveyId]?.get(event) ?: 0
            CapScope.DAY -> storage.capDayCount(surveyId, event.wire)
            CapScope.USER -> storage.capLifetimeCount(surveyId, event.wire)
        }

    /** Bump every counter for a (survey, event). Called from the four
     *  lifecycle points (show banner, dismiss banner, open chat, complete). */
    private fun recordCapEvent(surveyId: String, event: CapEvent) {
        val perSurvey = sessionCapCounts.getOrPut(surveyId) { mutableMapOf() }
        perSurvey[event] = (perSurvey[event] ?: 0) + 1
        storage.recordCapEvent(surveyId, event.wire)
    }
}
