package com.uxrate.sdk.services

import com.uxrate.sdk.models.*
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.util.Date

/**
 * Mock service for development and testing.
 * Used when `environment = Environment.MOCK` is passed to `UXRate.configure()`.
 *
 * Optionally accepts screen names so customers can quickly test the SDK in their
 * own app without a dashboard account.
 */
class MockSurveyService(screens: List<String>? = null) : SurveyService {

    private val pagePattern: String = if (!screens.isNullOrEmpty()) {
        screens.joinToString("|") { "^${it}$" }
    } else {
        "(?i).*home.*|.*product.*|^profile$"
    }

    private var userTurnCount = 0

    override suspend fun fetchConfiguration(apiKey: String): SDKConfig {
        return SDKConfig(
            surveys = listOf(
                SurveyConfig(
                    surveyId = "mock-survey-1",
                    name = "Mock Survey",
                    triggers = listOf(
                        TriggerRule(
                            type = "page_visit",
                            conditions = mapOf(
                                "pagePattern" to CodableValue.StringValue(pagePattern)
                            )
                        )
                    ),
                    triggerLogic = "AND",
                    frequency = FrequencyConfig(
                        maxPerUser = 99,
                        cooldownDays = 0,
                        maxPerSession = 99
                    ),
                    appearance = AppearanceConfig(
                        headline = "Share your thoughts",
                        subtext = "Take a short AI-powered interview and help us improve.",
                        callToAction = "Start Interview",
                        position = BannerPosition.NAVIGATION
                    )
                ),
                SurveyConfig(
                    surveyId = "mock-survey-2",
                    name = "Mock Feedback",
                    triggers = listOf(
                        TriggerRule(
                            type = "page_visit",
                            conditions = mapOf(
                                "pagePattern" to CodableValue.StringValue(pagePattern)
                            )
                        )
                    ),
                    triggerLogic = "AND",
                    frequency = FrequencyConfig(
                        maxPerUser = 99,
                        cooldownDays = 0,
                        maxPerSession = 99
                    ),
                    appearance = AppearanceConfig(
                        headline = "Quick feedback?",
                        subtext = "Help us understand your experience.",
                        callToAction = "Sure!",
                        position = BannerPosition.HEADER
                    )
                )
            ),
            settings = GlobalSettings(maxSurveysPerDay = 99),
            cacheExpiresAt = Date(System.currentTimeMillis() + 3600_000)
        )
    }

    override suspend fun createSession(): List<String> {
        delay(300)
        userTurnCount = 0
        return listOf(
            "Hi there! Thanks for taking the time to chat with us.",
            "I'd love to hear about your experience. Let's get started!"
        )
    }

    override suspend fun sendMessage(
        message: String,
        conversationHistory: List<ChatMessage>
    ): ChatReply {
        delay(400)

        val responses = listOf(
            ChatReply(
                content = "That's really helpful to know. Can you tell me more about what brought you here today?",
                isCompleted = false
            ),
            ChatReply(
                content = "Interesting! How would you rate your overall experience so far?",
                isCompleted = false
            ),
            ChatReply(
                content = "Thanks for sharing. Is there anything specific you'd like to see improved?",
                isCompleted = false
            ),
            ChatReply(
                content = "Great feedback! One last question — would you recommend us to a friend?",
                isCompleted = false
            ),
            ChatReply(
                content = "Thank you so much for your time! Your feedback is incredibly valuable to us.",
                isCompleted = true
            )
        )

        val index = userTurnCount.coerceAtMost(responses.size - 1)
        userTurnCount++
        return responses[index]
    }

    override suspend fun sendEvents(participantId: String, events: List<SdkEventItem>) {
        // No-op for mock service
    }

    override suspend fun uploadReplayFrames(
        participantId: String,
        metadata: JSONObject,
        frames: List<ReplayFrame>
    ) {
        // No-op for mock service
    }
}
