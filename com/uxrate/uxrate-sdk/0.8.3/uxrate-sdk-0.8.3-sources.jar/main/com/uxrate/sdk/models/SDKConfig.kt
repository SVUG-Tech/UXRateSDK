package com.uxrate.sdk.models

import com.uxrate.sdk.services.ReplayConfig
import java.util.Date

// MARK: - Public Enums

/**
 * Banner display position on screen.
 * Maps to iOS BannerPosition enum.
 */
enum class BannerPosition {
    /** Banner at top of screen */
    HEADER,
    /** Banner at bottom of screen (default) */
    NAVIGATION;

    companion object {
        fun from(value: String?): BannerPosition {
            return when (value?.lowercase()) {
                "header" -> HEADER
                "navigation" -> NAVIGATION
                else -> NAVIGATION
            }
        }
    }
}

/**
 * SDK color scheme theme.
 * Maps to iOS SDKTheme enum.
 */
enum class SDKTheme {
    /** Follow device/system setting */
    AUTO,
    /** Force light appearance */
    LIGHT,
    /** Force dark appearance */
    DARK;

    companion object {
        fun from(value: String?): SDKTheme {
            return when (value?.lowercase()) {
                "light" -> LIGHT
                "dark" -> DARK
                "auto" -> AUTO
                else -> AUTO
            }
        }
    }
}

/**
 * Strategy for resolving multiple matching surveys.
 * Maps to iOS OverlapStrategy enum.
 */
enum class OverlapStrategy {
    /** Show first matching survey in config array order (default) */
    SHOW_FIRST,
    /** Show last matching survey */
    SHOW_LAST,
    /** Randomly pick one from matching surveys */
    SHOW_RANDOM,
    /** Show nothing if multiple surveys match */
    SHOW_NONE;

    companion object {
        fun from(value: String?): OverlapStrategy {
            return when (value?.lowercase()) {
                "showfirst" -> SHOW_FIRST
                "showlast" -> SHOW_LAST
                "showrandom" -> SHOW_RANDOM
                "shownone" -> SHOW_NONE
                else -> SHOW_FIRST
            }
        }
    }
}

// MARK: - CodableValue (flexible JSON scalar)

/**
 * Represents a flexible JSON scalar value.
 * Maps to iOS CodableValue enum.
 */
sealed class CodableValue {
    data class StringValue(val value: String) : CodableValue()
    data class IntValue(val value: Int) : CodableValue()
    data class DoubleValue(val value: Double) : CodableValue()
    data class BoolValue(val value: Boolean) : CodableValue()

    val stringValue: String?
        get() = (this as? StringValue)?.value

    val intValue: Int?
        get() = (this as? IntValue)?.value

    val doubleValue: Double?
        get() = when (this) {
            is DoubleValue -> value
            is IntValue -> value.toDouble()
            else -> null
        }

    val boolValue: Boolean?
        get() = (this as? BoolValue)?.value
}

// MARK: - SDK Config Models

data class SDKConfig(
    val surveys: List<SurveyConfig>,
    val settings: GlobalSettings,
    val cacheExpiresAt: Date
)

data class SurveyConfig(
    val surveyId: String,
    val name: String,
    /** PR 3 trigger model — list of OR-combined trigger groups. See
     *  `TRIGGERS_SPEC.md` §2. */
    val triggers: List<Trigger>,
    val frequency: FrequencyConfig,
    val appearance: AppearanceConfig,
    val replayConfig: ReplayConfig? = null,
    // Higher priority wins when multiple studies match the same screen.
    // Defaults to 0 if the server doesn't send one.
    val priority: Int = 0,
    /** Per-event caps sourced from `targetTrigger.caps` (with legacy
     *  frequency fallback — see [resolveTargetCaps]). */
    val caps: TargetCaps = TargetCaps.UNLIMITED,
)

/** A single AND-group of screen / event rules. A study fires when ANY of its
 *  triggers match. */
data class Trigger(
    val id: String?,
    val screens: List<ScreenRule>,
    val events: List<EventRule>,
    /** "all" → every event rule must pass. "any" → at least one. */
    val eventLogic: String = "all"
)

data class ScreenRule(
    /** "name" | "contains" | "regex". */
    val matchType: String,
    val value: String
)

data class EventRule(
    val eventName: String,
    val count: Int,
    /** "session" — counter persists for the whole SDK session.
     *  "on_screen" — per-(screen, event) counter; increments only while
     *  `currentScreen` equals the screen, but persists across visits.
     *  Both counters are cleared on cold start (`configure`). */
    val scope: String
)

data class FrequencyConfig(
    val maxPerUser: Int,
    val cooldownDays: Int,
    val maxPerSession: Int
)

data class AppearanceConfig(
    val headline: String,
    val subtext: String,
    val callToAction: String,
    val position: BannerPosition,
    val chatTitle: String = "Share your experience",
    val colors: BannerColorPalette = BannerColorPalette.DEFAULTS
)

data class BannerColorTokens(
    val background: String,
    val text: String,
    val primary: String
)

data class BannerColorPalette(
    val light: BannerColorTokens,
    val dark: BannerColorTokens
) {
    fun tokens(isDark: Boolean): BannerColorTokens = if (isDark) dark else light

    companion object {
        val DEFAULTS = BannerColorPalette(
            light = BannerColorTokens(
                background = "#FFFFFF",
                text = "#111111",
                primary = "#1A1E40"
            ),
            dark = BannerColorTokens(
                background = "#1D293D",
                text = "#FFFFFF",
                primary = "#FFFFFF"
            )
        )
    }
}

data class GlobalSettings(
    val maxSurveysPerDay: Int
)

// MARK: - Active Survey State

data class ActiveSurveyState(
    val sdkConfig: SDKConfig,
    val activeSurvey: SurveyConfig
) {
    val headline: String get() = activeSurvey.appearance.headline
    val subtext: String get() = activeSurvey.appearance.subtext
    val callToAction: String get() = activeSurvey.appearance.callToAction
    val position: BannerPosition get() = activeSurvey.appearance.position
    val chatTitle: String get() = activeSurvey.appearance.chatTitle
    val surveyId: String get() = activeSurvey.surveyId
    val caps: TargetCaps get() = activeSurvey.caps

    fun bannerTokens(isDark: Boolean): BannerColorTokens =
        activeSurvey.appearance.colors.tokens(isDark)
}
