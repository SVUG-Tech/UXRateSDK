package com.uxrate.sdk.services

import com.uxrate.sdk.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date

/**
 * Production network client for the UXRate API.
 * Maps to iOS LiveSurveyService actor.
 * Uses HttpURLConnection (zero external deps) with synchronized blocks for thread safety.
 */
class LiveSurveyService(
    private val baseURL: String = "https://app.uxrate.com",
    private val participantId: String
) : SurveyService {

    // Synchronized mutable state
    private var apiKey: String? = null
    private var studyId: String? = null
    private var chatToken: String? = null
    private var interviewId: String? = null

    /** Locale override set by UXRate.setLocale(). Null = use device locale. */
    @Volatile var localeOverride: java.util.Locale? = null

    /**
     * Returns a BCP 47 Accept-Language value for the active locale.
     */
    private fun acceptLanguageHeader(): String {
        val locale = localeOverride ?: java.util.Locale.getDefault()
        return if (locale.country.isNotEmpty()) "${locale.language}-${locale.country}" else locale.language
    }

    // MARK: - SurveyService Implementation

    override suspend fun fetchConfiguration(apiKey: String, participantId: String): SDKConfig =
        withContext(Dispatchers.IO) {
            synchronized(this@LiveSurveyService) {
                this@LiveSurveyService.apiKey = apiKey
            }

            // Encode defensively even though participantId is always a UUID today.
            val encodedPid = java.net.URLEncoder.encode(participantId, "UTF-8")
            val url = URL("$baseURL/api/sdk/init?participantId=$encodedPid")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("X-Uxrate-Platform", "android")
                setRequestProperty("Accept-Language", acceptLanguageHeader())
            }

            try {
                validate(connection)
                val responseBody = readResponse(connection)
                val json = JSONObject(responseBody)
                val studiesResponse = StudiesResponse.fromJson(json)
                val config = mapToSDKConfig(studiesResponse)

                synchronized(this@LiveSurveyService) {
                    this@LiveSurveyService.studyId = config.surveys.firstOrNull()?.surveyId
                }

                config
            } finally {
                connection.disconnect()
            }
        }

    override suspend fun createSession(): List<ChatSeedMessage> = withContext(Dispatchers.IO) {
        createInterview()
        fetchChatHistory()
    }

    override suspend fun sendMessage(
        message: String,
        conversationHistory: List<ChatMessage>
    ): ChatReply = withContext(Dispatchers.IO) {
        val currentInterviewId: String
        val currentChatToken: String

        synchronized(this@LiveSurveyService) {
            currentInterviewId = interviewId
                ?: throw LiveSurveyError.NotConfigured
            currentChatToken = chatToken
                ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/interviews/$currentInterviewId/chat")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "Bearer $currentChatToken")
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
        }

        try {
            val requestBody = JSONObject().apply {
                put("content", message)
            }
            writeBody(connection, requestBody.toString())

            validate(connection)
            val responseBody = readResponse(connection)
            val json = JSONObject(responseBody)

            val messageObj = json.getJSONObject("message")
            val content = messageObj.getString("content")
            val isCompleted = json.optBoolean("isCompleted", false)

            ChatReply(content = content, isCompleted = isCompleted)
        } finally {
            connection.disconnect()
        }
    }

    override suspend fun sendEvents(
        participantId: String,
        events: List<SdkEventItem>
    ): Unit = withContext(Dispatchers.IO) {
        val currentApiKey: String
        synchronized(this@LiveSurveyService) {
            currentApiKey = apiKey ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/sdk/events")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "Bearer $currentApiKey")
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
        }

        try {
            val eventsArray = JSONArray()
            events.forEach { eventsArray.put(it.toJson()) }

            val requestBody = JSONObject().apply {
                put("participantId", participantId)
                put("events", eventsArray)
            }
            writeBody(connection, requestBody.toString())

            validate(connection)
        } finally {
            connection.disconnect()
        }
    }

    // MARK: - Private Helpers

    private suspend fun createInterview() = withContext(Dispatchers.IO) {
        val currentApiKey: String
        val currentStudyId: String

        synchronized(this@LiveSurveyService) {
            currentApiKey = apiKey ?: throw LiveSurveyError.NotConfigured
            currentStudyId = studyId ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/sdk/interviews")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "Bearer $currentApiKey")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept-Language", acceptLanguageHeader())
            doOutput = true
        }

        try {
            val requestBody = JSONObject().apply {
                put("studyId", currentStudyId)
                put("participantId", participantId)
            }
            writeBody(connection, requestBody.toString())

            // POST /api/sdk/interviews returns 409 { error: "already_participated" }
            // when the participant has a completed interview for this study.
            // Surface as a typed error so SurveyManager can render the terminal
            // "thanks, you've already participated" state rather than a generic
            // network failure message.
            if (connection.responseCode == 409) {
                val errorBody = runCatching { readErrorResponse(connection) }.getOrNull()
                val errorCode = errorBody?.let {
                    runCatching { JSONObject(it).optString("error") }.getOrNull()
                }
                if (errorCode == "already_participated") {
                    throw LiveSurveyError.AlreadyParticipated
                }
            }
            validate(connection)
            val responseBody = readResponse(connection)
            val json = JSONObject(responseBody)

            val interview = json.getJSONObject("interview")
            val newInterviewId = interview.getString("id")
            val newChatToken = json.getString("chatToken")

            synchronized(this@LiveSurveyService) {
                this@LiveSurveyService.interviewId = newInterviewId
                this@LiveSurveyService.chatToken = newChatToken
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun readErrorResponse(connection: HttpURLConnection): String? {
        val stream = connection.errorStream ?: return null
        return BufferedReader(InputStreamReader(stream)).use { it.readText() }
    }

    /**
     * Fetches every persisted message for the active interview — both AI
     * and participant turns, in order. Used to render the full prior
     * history when the server resumes an existing `started` interview.
     */
    private suspend fun fetchChatHistory(): List<ChatSeedMessage> = withContext(Dispatchers.IO) {
        val currentInterviewId: String
        val currentChatToken: String

        synchronized(this@LiveSurveyService) {
            currentInterviewId = interviewId ?: throw LiveSurveyError.NotConfigured
            currentChatToken = chatToken ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/interviews/$currentInterviewId/chat")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "Bearer $currentChatToken")
        }

        try {
            validate(connection)
            val responseBody = readResponse(connection)
            val json = JSONObject(responseBody)

            val messagesArray = json.getJSONArray("messages")
            val seeds = mutableListOf<ChatSeedMessage>()

            for (i in 0 until messagesArray.length()) {
                val msg = messagesArray.getJSONObject(i)
                seeds.add(
                    ChatSeedMessage(
                        content = msg.getString("content"),
                        isParticipant = msg.optBoolean("isParticipant", false)
                    )
                )
            }

            seeds
        } finally {
            connection.disconnect()
        }
    }

    override suspend fun uploadReplayFrames(
        participantId: String,
        metadata: JSONObject,
        frames: List<ReplayFrame>
    ) = withContext(Dispatchers.IO) {
        val boundary = "UXRateReplayBoundary"
        val url = URL("$baseURL/api/sdk/replay")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            val currentApiKey = synchronized(this@LiveSurveyService) { apiKey }
            if (currentApiKey != null) {
                setRequestProperty("Authorization", "Bearer $currentApiKey")
            }
            doOutput = true
        }

        try {
            val outputStream = DataOutputStream(connection.outputStream)

            // Write metadata part
            outputStream.writeBytes("--$boundary\r\n")
            outputStream.writeBytes("Content-Disposition: form-data; name=\"metadata\"\r\n")
            outputStream.writeBytes("Content-Type: application/json\r\n\r\n")
            outputStream.writeBytes(metadata.toString())
            outputStream.writeBytes("\r\n")

            // Write each frame as a file part
            frames.forEachIndexed { index, frame ->
                outputStream.writeBytes("--$boundary\r\n")
                outputStream.writeBytes(
                    "Content-Disposition: form-data; name=\"frame_$index\"; filename=\"frame_$index.jpg\"\r\n"
                )
                outputStream.writeBytes("Content-Type: image/jpeg\r\n\r\n")
                outputStream.write(frame.imageData)
                outputStream.writeBytes("\r\n")
            }

            outputStream.writeBytes("--$boundary--\r\n")
            outputStream.flush()
            outputStream.close()

            validate(connection)
        } finally {
            connection.disconnect()
        }
    }

    // MARK: - Config Mapping

    private fun mapToSDKConfig(response: StudiesResponse): SDKConfig {
        val surveys = response.studies
            .filter { it.isActive && it.platform == "android" }
            .map { study ->
                SurveyConfig(
                    surveyId = study.id,
                    name = study.name,
                    triggers = mapTriggers(study),
                    frequency = FrequencyConfig(
                        maxPerUser = 99,
                        cooldownDays = 0,
                        maxPerSession = 99
                    ),
                    appearance = AppearanceConfig(
                        headline = study.appearance.headline,
                        subtext = study.appearance.subtext,
                        callToAction = study.appearance.callToAction,
                        position = BannerPosition.from(study.appearance.position),
                        chatTitle = study.appearance.chatTitle,
                        colors = mergeBannerColors(study.appearance.colors)
                    ),
                    replayConfig = study.replayConfig,
                    priority = study.priority,
                    caps = resolveTargetCaps(
                        caps = study.targetTrigger?.caps,
                        frequency = study.targetTrigger?.frequency,
                    )
                )
            }

        return SDKConfig(
            surveys = surveys,
            settings = GlobalSettings(maxSurveysPerDay = 99),
            cacheExpiresAt = Date(System.currentTimeMillis() + 3600_000) // 1 hour
        )
    }

    /**
     * Collapse a partial/nullable wire palette onto the SDK defaults so the
     * banner always has a complete set of tokens. Missing modes or missing
     * individual colors fall back to the default palette.
     */
    private fun mergeBannerColors(wire: StudyBannerColors?): BannerColorPalette {
        val defaults = BannerColorPalette.DEFAULTS
        return BannerColorPalette(
            light = mergeTokens(wire?.light, defaults.light),
            dark = mergeTokens(wire?.dark, defaults.dark)
        )
    }

    private fun mergeTokens(
        wire: StudyBannerPalette?,
        fallback: BannerColorTokens
    ): BannerColorTokens {
        return BannerColorTokens(
            background = wire?.background ?: fallback.background,
            text = wire?.text ?: fallback.text,
            primary = wire?.primary ?: fallback.primary
        )
    }

    /**
     * Resolves a study's trigger list from the wire `triggers[]` field.
     * Empty event names and blank screen values are stripped as
     * defence-in-depth; the server already does the same in
     * `normalizeTriggers`.
     *
     * The pre-PR-4 fallback that derived this list from `targetTrigger`
     * was removed in 0.7 — server has been emitting `triggers[]` since
     * the panel rewrite landed and we no longer need to support a server
     * that doesn't.
     */
    private fun mapTriggers(study: Study): List<Trigger> {
        val source = study.triggers ?: return emptyList()
        return source.mapNotNull { wire ->
            val screens = wire.screens
                .filter { it.value.isNotBlank() || it.matchType == "regex" }
                .map { ScreenRule(matchType = it.matchType, value = it.value) }
            val events = wire.events
                .map { it.copy(eventName = it.eventName.trim()) }
                .filter { it.eventName.isNotEmpty() }
                .map { EventRule(eventName = it.eventName, count = it.count, scope = it.scope) }
            if (screens.isEmpty() && events.isEmpty()) return@mapNotNull null
            Trigger(
                id = wire.id,
                screens = screens,
                events = events,
                eventLogic = if (wire.eventLogic == "any") "any" else "all"
            )
        }
    }

    // MARK: - HTTP Helpers

    private fun validate(connection: HttpURLConnection) {
        val statusCode = connection.responseCode
        if (statusCode !in 200..299) {
            throw LiveSurveyError.HttpError(statusCode)
        }
    }

    private fun readResponse(connection: HttpURLConnection): String {
        return BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
            reader.readText()
        }
    }

    private fun writeBody(connection: HttpURLConnection, body: String) {
        OutputStreamWriter(connection.outputStream).use { writer ->
            writer.write(body)
            writer.flush()
        }
    }

    // MARK: - Error Types

    sealed class LiveSurveyError : Exception() {
        object NotConfigured : LiveSurveyError() {
            private fun readResolve(): Any = NotConfigured
            override val message: String = "LiveSurveyService has not been configured yet."
        }

        data class HttpError(val statusCode: Int) : LiveSurveyError() {
            override val message: String = "HTTP error $statusCode."
        }

        /**
         * Server reports the participant has already completed this study
         * (POST /api/sdk/interviews → 409 { error: "already_participated" }).
         * SurveyManager surfaces this as a terminal "thanks, already
         * participated" state instead of a generic failure.
         */
        object AlreadyParticipated : LiveSurveyError() {
            private fun readResolve(): Any = AlreadyParticipated
            override val message: String = "Already participated in this study."
        }
    }
}
