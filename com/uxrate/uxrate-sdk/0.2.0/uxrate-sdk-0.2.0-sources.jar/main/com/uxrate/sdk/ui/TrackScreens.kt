package com.uxrate.sdk.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.uxrate.sdk.UXRate

/**
 * Auto-tracks all navigation destinations as UXRate screen names.
 *
 * Call once where you create your NavController — every route change
 * is automatically reported to the SDK:
 *
 * ```kotlin
 * val navController = rememberNavController()
 * navController.TrackScreens()
 *
 * NavHost(navController, startDestination = "home") {
 *     composable("home") { HomeScreen() }
 *     composable("profile") { ProfileScreen() }
 *     // ...
 * }
 * ```
 *
 * By default, the route string is used as the screen name. Provide a
 * [nameMapper] to customise:
 *
 * ```kotlin
 * navController.TrackScreens { route ->
 *     when (route) {
 *         "home" -> "Home"
 *         "profile/{id}" -> "Profile"
 *         else -> route.replaceFirstChar { it.uppercase() }
 *     }
 * }
 * ```
 *
 * This replaces the need to add [SurveyScreen] on every individual screen.
 */
@Composable
fun NavController.TrackScreens(
    nameMapper: ((String) -> String)? = null,
) {
    val entry by currentBackStackEntryAsState()
    val route = entry?.destination?.route

    LaunchedEffect(route) {
        if (route == null) return@LaunchedEffect
        val screenName = nameMapper?.invoke(route) ?: route.replaceFirstChar { it.uppercase() }
        UXRate.setScreen(screenName)
    }
}
