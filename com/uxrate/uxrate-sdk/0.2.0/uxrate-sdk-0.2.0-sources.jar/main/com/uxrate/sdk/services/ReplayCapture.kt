package com.uxrate.sdk.services

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.view.PixelCopy
import com.uxrate.sdk.UXRate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.min

// MARK: - Data Classes

data class QualityProfile(
    val fps: Long,
    val scale: Float,
    val jpegQuality: Int,
    val maxBufferMemoryBytes: Int,
    val maxFrames: Int
) {
    companion object {
        val LOW = QualityProfile(1000L, 0.4f, 25, 5 * 1024 * 1024, 1800)
        val MEDIUM = QualityProfile(500L, 0.5f, 35, 8 * 1024 * 1024, 3600)
        val HIGH = QualityProfile(333L, 0.5f, 45, 12 * 1024 * 1024, 5400)

        fun from(name: String): QualityProfile = when (name.lowercase()) {
            "low" -> LOW
            "high" -> HIGH
            "medium", "auto" -> MEDIUM
            else -> MEDIUM
        }
    }
}

data class ReplayConfig(
    val scope: String,              // "off", "sampled", "all"
    val trigger: String,            // "participants", "triggered", "always"
    val triggerScreens: List<ReplayTrigger>?,
    val stopTriggers: List<ReplayTrigger>?,
    val sampleRate: Double?,        // 0.0 to 1.0
    val bufferSeconds: Int,         // default 30
    val maxFramesPerSession: Int,   // default 1800
    val quality: String = "auto"
) {
    companion object {
        fun fromJson(json: JSONObject): ReplayConfig {
            val triggersArray = json.optJSONArray("triggerScreens")
            val triggerScreens = if (triggersArray != null) {
                val list = mutableListOf<ReplayTrigger>()
                for (i in 0 until triggersArray.length()) {
                    list.add(ReplayTrigger.fromJson(triggersArray.getJSONObject(i)))
                }
                list
            } else {
                null
            }

            val stopArray = json.optJSONArray("stopTriggers")
            val stopTriggers = if (stopArray != null) {
                val list = mutableListOf<ReplayTrigger>()
                for (i in 0 until stopArray.length()) {
                    list.add(ReplayTrigger.fromJson(stopArray.getJSONObject(i)))
                }
                list
            } else {
                null
            }

            // sampleRate comes from dashboard as Int 1-100, convert to 0.0-1.0
            val sampleRate = if (json.has("sampleRate")) {
                json.optInt("sampleRate", 0) / 100.0
            } else {
                null
            }

            return ReplayConfig(
                scope = json.optString("scope", "off"),
                trigger = json.optString("trigger", "participants"),
                triggerScreens = triggerScreens,
                stopTriggers = stopTriggers,
                sampleRate = sampleRate,
                bufferSeconds = json.optInt("bufferSeconds", 30),
                maxFramesPerSession = json.optInt("maxFramesPerSession", 1800),
                quality = json.optString("quality", "auto")
            )
        }
    }
}

data class ReplayTrigger(
    val type: String,   // "screen", "event"
    val value: String
) {
    companion object {
        fun fromJson(json: JSONObject): ReplayTrigger {
            return ReplayTrigger(
                type = json.optString("type", ""),
                value = json.optString("value", "")
            )
        }
    }
}

data class ReplayFrame(
    val imageData: ByteArray,   // JPEG compressed (empty for duplicates)
    val timestamp: String,      // ISO 8601
    val screenName: String?,
    val index: Int,
    val isDuplicate: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ReplayFrame) return false
        return index == other.index &&
                timestamp == other.timestamp &&
                screenName == other.screenName &&
                isDuplicate == other.isDuplicate &&
                imageData.contentEquals(other.imageData)
    }

    override fun hashCode(): Int {
        var result = imageData.contentHashCode()
        result = 31 * result + timestamp.hashCode()
        result = 31 * result + (screenName?.hashCode() ?: 0)
        result = 31 * result + index
        result = 31 * result + isDuplicate.hashCode()
        return result
    }
}

// MARK: - ReplayCapture

/**
 * Captures periodic screenshots of the app for session replay.
 * Uses PixelCopy on API 26+ with View.draw(canvas) fallback for API 24-25.
 *
 * Supports deferred start for "triggered" mode where capture begins only when
 * a matching screen or event trigger fires via [activateCapture].
 *
 * Frames are uploaded periodically (every 30s), on specific events, and when
 * the app enters background (without stopping capture).
 */
class ReplayCapture(
    private val baseURL: String,
    private val apiKey: String
) {
    companion object {
        private const val TAG = "UXRate"
        private const val FLUSH_INTERVAL_MS = 30_000L
        private const val BOUNDARY = "UXRateReplayBoundary"
        private const val AUTO_ADAPT_FLUSH_COUNT = 5

        fun shouldSample(participantId: String, rate: Double): Boolean {
            val hash = participantId.hashCode()
            return (abs(hash) % 100) < (rate * 100).toInt()
        }
    }

    private val buffer = mutableListOf<ReplayFrame>()
    private var config: ReplayConfig? = null
    private var isCapturing = false
    private var handler: Handler? = null
    private var frameIndex = 0
    private var participantId: String = ""
    private var totalFramesCaptured = 0
    private var currentScreenName: String? = null

    /** Active quality profile derived from config or auto-adaptation. */
    private var qualityProfile: QualityProfile = QualityProfile.MEDIUM

    /** Whether the quality setting is "auto" and should adapt based on flush duration. */
    private var isAutoQuality = true

    /** Tracks flush durations for auto-adaptation. */
    private var flushDurations = mutableListOf<Long>()
    private var flushCount = 0

    /** When true, capture is configured but waiting for a trigger match to start. */
    private var isArmed = false

    /** Hash of the previous frame's JPEG data for duplicate detection. */
    private var lastFrameDataHash = 0

    /** Consecutive flush failures for exponential backoff. */
    private var consecutiveFailures = 0

    /** Closure called when the buffer should be flushed (set by SurveyManager). */
    var flushHandler: ((ReplayCapture) -> Unit)? = null

    /** Reference to the current activity for capture after resume. */
    private var currentActivity: Activity? = null

    private val captureRunnable = object : Runnable {
        override fun run() {
            if (!isCapturing) return
            currentActivity?.let { captureFrame(it) }
            handler?.postDelayed(this, qualityProfile.fps)
        }
    }

    private val flushRunnable = object : Runnable {
        override fun run() {
            if (!isCapturing) return
            synchronized(buffer) {
                if (buffer.isNotEmpty()) {
                    flushHandler?.invoke(this@ReplayCapture)
                }
            }
            handler?.postDelayed(this, FLUSH_INTERVAL_MS)
        }
    }

    private val isoFormat: SimpleDateFormat
        get() = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

    private val currentBufferBytes: Int
        get() = synchronized(buffer) { buffer.sumOf { it.imageData.size } }

    // MARK: - Public API

    /**
     * Stores config and checks sampling to decide if capture should be enabled.
     * For "triggered" mode, sets [isArmed] — capture defers until a trigger match.
     */
    fun configure(config: ReplayConfig, participantId: String) {
        this.config = config
        this.participantId = participantId

        // Set quality profile from config
        isAutoQuality = config.quality.lowercase() == "auto"
        qualityProfile = QualityProfile.from(config.quality)

        // For "sampled" scope, check if this participant is in the sample
        if (config.scope == "sampled") {
            val rate = config.sampleRate ?: 0.0
            if (!shouldSample(participantId, rate)) {
                this.config = config.copy(scope = "off")
                if (UXRate.loggingEnabled) {
                    Log.d(TAG, "Replay: participant not in sample (rate=$rate)")
                }
                return
            }
        }

        // Deferred start for "triggered" mode
        if (config.trigger == "triggered") {
            isArmed = true
        }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Replay configured: scope=${this.config?.scope}, trigger=${this.config?.trigger}, armed=$isArmed")
        }
    }

    /**
     * Starts periodic capture and flush timers on the main thread handler.
     */
    fun startCapturing(activity: Activity) {
        val cfg = config ?: return
        if (cfg.scope == "off") return
        if (isCapturing) return

        isCapturing = true
        currentActivity = activity

        handler = Handler(Looper.getMainLooper())
        handler?.post(captureRunnable)
        handler?.postDelayed(flushRunnable, FLUSH_INTERVAL_MS)

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Replay: capture started")
        }
    }

    /**
     * Activates capture when a start trigger matches (only for "triggered" mode).
     * No-op if not armed or already capturing.
     */
    fun activateCapture(activity: Activity) {
        if (!isArmed) return
        isArmed = false
        startCapturing(activity)
    }

    /**
     * Stops capture and flush timers.
     */
    fun stopCapturing() {
        if (!isCapturing) return
        isCapturing = false
        handler?.removeCallbacksAndMessages(null)
        handler = null

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Replay: capture stopped (frames=${buffer.size})")
        }
    }

    /**
     * Sets the current screen name for tagging frames.
     */
    fun setCurrentScreen(screenName: String?) {
        currentScreenName = screenName
    }

    /**
     * Determines whether capture should start based on trigger config.
     */
    fun shouldCapture(forScreen: String? = null, forEvent: String? = null): Boolean {
        val cfg = config ?: return false

        if (cfg.scope == "off") return false

        return when (cfg.trigger) {
            "always" -> true
            "participants" -> true
            "triggered" -> {
                val triggers = cfg.triggerScreens ?: return false
                triggers.any { trigger ->
                    when (trigger.type) {
                        "screen" -> forScreen != null && trigger.value == forScreen
                        "event" -> forEvent != null && trigger.value == forEvent
                        else -> false
                    }
                }
            }
            else -> false
        }
    }

    /**
     * Returns whether capture should stop for the given screen or event.
     */
    fun shouldStop(forScreen: String? = null, forEvent: String? = null): Boolean {
        val cfg = config ?: return false
        val stops = cfg.stopTriggers ?: return false
        if (stops.isEmpty()) return false

        return stops.any { trigger ->
            when (trigger.type) {
                "screen" -> forScreen != null && trigger.value == forScreen
                "event" -> forEvent != null && trigger.value == forEvent
                else -> false
            }
        }
    }

    /**
     * Captures the current screen as a JPEG-compressed frame.
     * Uses PixelCopy on API 26+, View.draw(canvas) fallback for API 24-25.
     */
    fun captureFrame(activity: Activity) {
        val cfg = config ?: return
        if (cfg.scope == "off") return

        try {
            val window = activity.window
            val decorView = window.decorView
            val width = decorView.width
            val height = decorView.height

            if (width <= 0 || height <= 0) return

            val scaledWidth = (width * qualityProfile.scale).toInt()
            val scaledHeight = (height * qualityProfile.scale).toInt()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // API 26+: Use PixelCopy for accurate capture
                val fullBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val handlerThread = HandlerThread("PixelCopyThread")
                handlerThread.start()

                PixelCopy.request(window, fullBitmap, { result ->
                    try {
                        if (result == PixelCopy.SUCCESS) {
                            val scaledBitmap = Bitmap.createScaledBitmap(
                                fullBitmap, scaledWidth, scaledHeight, true
                            )
                            addFrameFromBitmap(scaledBitmap)
                            scaledBitmap.recycle()
                        }
                        fullBitmap.recycle()
                    } finally {
                        handlerThread.quitSafely()
                    }
                }, Handler(handlerThread.looper))
            } else {
                // API 24-25: Fallback using View.draw(canvas)
                val bitmap = Bitmap.createBitmap(scaledWidth, scaledHeight, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.scale(qualityProfile.scale, qualityProfile.scale)
                decorView.draw(canvas)
                addFrameFromBitmap(bitmap)
                bitmap.recycle()
            }
        } catch (e: Exception) {
            if (UXRate.loggingEnabled) {
                Log.e(TAG, "Replay: frame capture failed: ${e.message}")
            }
        }
    }

    /**
     * Flushes the buffer by uploading frames to the server.
     * On failure, retries with exponential backoff. After 5 consecutive failures,
     * drops the oldest half of the buffer.
     */
    suspend fun flushBuffer(studyId: String?) {
        val framesToUpload: List<ReplayFrame>

        synchronized(buffer) {
            if (buffer.isEmpty()) return
            framesToUpload = buffer.toList()
            buffer.clear()
        }

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Replay: flushing ${framesToUpload.size} frames")
        }

        val flushStartTime = System.currentTimeMillis()

        try {
            withContext(Dispatchers.IO) {
                uploadFrames(framesToUpload, studyId)
            }
            consecutiveFailures = 0

            // Track flush duration for auto-adaptation
            val flushDurationMs = System.currentTimeMillis() - flushStartTime
            if (isAutoQuality) {
                adaptQuality(flushDurationMs)
            }
        } catch (e: Exception) {
            consecutiveFailures++
            val backoffMs = min(1000L * (1L shl consecutiveFailures), 60_000L)
            if (UXRate.loggingEnabled) {
                Log.e(TAG, "Replay: upload failed (attempt $consecutiveFailures): ${e.message}. Retrying in ${backoffMs}ms")
            }

            // Re-add frames to buffer on failure
            synchronized(buffer) {
                buffer.addAll(0, framesToUpload)
                val maxBufferSize = config?.bufferSeconds ?: 30
                while (buffer.size > maxBufferSize) {
                    buffer.removeAt(0)
                }

                // Drop oldest half after repeated failures
                if (consecutiveFailures >= 5 && buffer.size > maxBufferSize / 2) {
                    val dropCount = buffer.size / 2
                    repeat(dropCount) { buffer.removeAt(0) }
                    if (UXRate.loggingEnabled) {
                        Log.d(TAG, "Replay: dropped $dropCount oldest frames after repeated failures")
                    }
                }
            }

            // Retry with backoff
            delay(backoffMs)
            flushBuffer(studyId)
        }
    }

    // MARK: - Private Helpers

    /**
     * Evaluates flush performance every [AUTO_ADAPT_FLUSH_COUNT] flushes and
     * switches quality profile when running in "auto" mode.
     * - <5s average → HIGH
     * - 5-15s average → MEDIUM
     * - >15s average → LOW
     */
    private fun adaptQuality(flushDurationMs: Long) {
        flushDurations.add(flushDurationMs)
        flushCount++

        if (flushCount % AUTO_ADAPT_FLUSH_COUNT != 0) return

        val avgDurationSec = flushDurations.average() / 1000.0
        flushDurations.clear()

        val newProfile = when {
            avgDurationSec < 5.0 -> QualityProfile.HIGH
            avgDurationSec <= 15.0 -> QualityProfile.MEDIUM
            else -> QualityProfile.LOW
        }

        if (newProfile != qualityProfile) {
            val oldFps = qualityProfile.fps
            qualityProfile = newProfile

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Replay: auto-adapted quality (avg flush=${avgDurationSec}s) → interval ${newProfile.fps}ms, scale ${newProfile.scale}, jpeg ${newProfile.jpegQuality}")
            }

            // Restart capture handler with new interval if currently capturing
            if (isCapturing && oldFps != newProfile.fps) {
                handler?.removeCallbacks(captureRunnable)
                handler?.post(captureRunnable)
            }
        }
    }

    private fun addFrameFromBitmap(bitmap: Bitmap) {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, qualityProfile.jpegQuality, stream)
        val imageData = stream.toByteArray()

        // Duplicate detection: compare hash with previous frame
        val currentHash = imageData.contentHashCode()
        val isDuplicate = currentHash == lastFrameDataHash && totalFramesCaptured > 0
        lastFrameDataHash = currentHash

        val frame = ReplayFrame(
            imageData = if (isDuplicate) ByteArray(0) else imageData,
            timestamp = isoFormat.format(Date()),
            screenName = currentScreenName,
            index = frameIndex++,
            isDuplicate = isDuplicate
        )

        synchronized(buffer) {
            val maxBufferSize = config?.bufferSeconds ?: 30
            if (buffer.size >= maxBufferSize) {
                buffer.removeAt(0)
            }
            buffer.add(frame)
        }

        totalFramesCaptured++

        // Emergency flush if buffer exceeds memory cap
        if (currentBufferBytes > qualityProfile.maxBufferMemoryBytes) {
            flushHandler?.invoke(this)
        }
    }

    /**
     * Uploads frames to the backend with proper auth header and metadata format.
     */
    private fun uploadFrames(frames: List<ReplayFrame>, studyId: String?) {
        val url = URL("$baseURL/api/sdk/replay")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$BOUNDARY")
            setRequestProperty("Authorization", "Bearer $apiKey")
            doOutput = true
        }

        try {
            val outputStream = DataOutputStream(connection.outputStream)

            // Build metadata matching server schema (startedAt/endedAt, not timestamps array)
            val metadata = JSONObject().apply {
                put("participantId", participantId)
                if (!studyId.isNullOrEmpty()) put("studyId", studyId)
                put("frameCount", frames.size)
                put("startedAt", frames.first().timestamp)
                put("endedAt", frames.last().timestamp)
            }

            outputStream.writeBytes("--$BOUNDARY\r\n")
            outputStream.writeBytes("Content-Disposition: form-data; name=\"metadata\"\r\n")
            outputStream.writeBytes("Content-Type: application/json\r\n\r\n")
            outputStream.writeBytes(metadata.toString())
            outputStream.writeBytes("\r\n")

            // Write each frame — duplicates use .dup extension
            frames.forEachIndexed { index, frame ->
                val ext = if (frame.isDuplicate) "dup" else "jpg"
                val filename = "${frame.index}_${frame.timestamp}.$ext"
                val mimeType = if (frame.isDuplicate) "application/octet-stream" else "image/jpeg"

                outputStream.writeBytes("--$BOUNDARY\r\n")
                outputStream.writeBytes(
                    "Content-Disposition: form-data; name=\"frame_$index\"; filename=\"$filename\"\r\n"
                )
                outputStream.writeBytes("Content-Type: $mimeType\r\n\r\n")
                outputStream.write(frame.imageData)
                outputStream.writeBytes("\r\n")
            }

            outputStream.writeBytes("--$BOUNDARY--\r\n")
            outputStream.flush()
            outputStream.close()

            val statusCode = connection.responseCode
            if (statusCode !in 200..299) {
                throw Exception("Replay upload failed with HTTP $statusCode")
            }

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Replay: uploaded ${frames.size} frames successfully")
            }
        } finally {
            connection.disconnect()
        }
    }
}
