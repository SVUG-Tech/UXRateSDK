package com.uxrate.sdk.services

import com.uxrate.sdk.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.regex.Pattern

/**
 * Production network client for the UXRate API.
 * Maps to iOS LiveSurveyService actor.
 * Uses HttpURLConnection (zero external deps) with synchronized blocks for thread safety.
 */
class LiveSurveyService(
    private val baseURL: String = "https://app.uxrate.com",
    private val participantId: String
) : SurveyService {

    // Synchronized mutable state
    private var apiKey: String? = null
    private var studyId: String? = null
    private var chatToken: String? = null
    private var interviewId: String? = null

    // MARK: - SurveyService Implementation

    override suspend fun fetchConfiguration(apiKey: String): SDKConfig =
        withContext(Dispatchers.IO) {
            synchronized(this@LiveSurveyService) {
                this@LiveSurveyService.apiKey = apiKey
            }

            val url = URL("$baseURL/api/sdk/init")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("Authorization", "Bearer $apiKey")
                setRequestProperty("X-Uxrate-Platform", "android")
            }

            try {
                validate(connection)
                val responseBody = readResponse(connection)
                val json = JSONObject(responseBody)
                val studiesResponse = StudiesResponse.fromJson(json)
                val config = mapToSDKConfig(studiesResponse)

                synchronized(this@LiveSurveyService) {
                    this@LiveSurveyService.studyId = config.surveys.firstOrNull()?.surveyId
                }

                config
            } finally {
                connection.disconnect()
            }
        }

    override suspend fun createSession(): List<String> = withContext(Dispatchers.IO) {
        createInterview()
        fetchInitialMessages()
    }

    override suspend fun sendMessage(
        message: String,
        conversationHistory: List<ChatMessage>
    ): ChatReply = withContext(Dispatchers.IO) {
        val currentInterviewId: String
        val currentChatToken: String

        synchronized(this@LiveSurveyService) {
            currentInterviewId = interviewId
                ?: throw LiveSurveyError.NotConfigured
            currentChatToken = chatToken
                ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/interviews/$currentInterviewId/chat")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "Bearer $currentChatToken")
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
        }

        try {
            val requestBody = JSONObject().apply {
                put("content", message)
            }
            writeBody(connection, requestBody.toString())

            validate(connection)
            val responseBody = readResponse(connection)
            val json = JSONObject(responseBody)

            val messageObj = json.getJSONObject("message")
            val content = messageObj.getString("content")
            val isCompleted = json.optBoolean("isCompleted", false)

            ChatReply(content = content, isCompleted = isCompleted)
        } finally {
            connection.disconnect()
        }
    }

    override suspend fun sendEvents(
        participantId: String,
        events: List<SdkEventItem>
    ): Unit = withContext(Dispatchers.IO) {
        val currentApiKey: String
        synchronized(this@LiveSurveyService) {
            currentApiKey = apiKey ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/sdk/events")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "Bearer $currentApiKey")
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
        }

        try {
            val eventsArray = JSONArray()
            events.forEach { eventsArray.put(it.toJson()) }

            val requestBody = JSONObject().apply {
                put("participantId", participantId)
                put("events", eventsArray)
            }
            writeBody(connection, requestBody.toString())

            validate(connection)
        } finally {
            connection.disconnect()
        }
    }

    // MARK: - Private Helpers

    private suspend fun createInterview() = withContext(Dispatchers.IO) {
        val currentApiKey: String
        val currentStudyId: String

        synchronized(this@LiveSurveyService) {
            currentApiKey = apiKey ?: throw LiveSurveyError.NotConfigured
            currentStudyId = studyId ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/sdk/interviews")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "Bearer $currentApiKey")
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
        }

        try {
            val requestBody = JSONObject().apply {
                put("studyId", currentStudyId)
                put("participantId", participantId)
            }
            writeBody(connection, requestBody.toString())

            validate(connection)
            val responseBody = readResponse(connection)
            val json = JSONObject(responseBody)

            val interview = json.getJSONObject("interview")
            val newInterviewId = interview.getString("id")
            val newChatToken = json.getString("chatToken")

            synchronized(this@LiveSurveyService) {
                this@LiveSurveyService.interviewId = newInterviewId
                this@LiveSurveyService.chatToken = newChatToken
            }
        } finally {
            connection.disconnect()
        }
    }

    private suspend fun fetchInitialMessages(): List<String> = withContext(Dispatchers.IO) {
        val currentInterviewId: String
        val currentChatToken: String

        synchronized(this@LiveSurveyService) {
            currentInterviewId = interviewId ?: throw LiveSurveyError.NotConfigured
            currentChatToken = chatToken ?: throw LiveSurveyError.NotConfigured
        }

        val url = URL("$baseURL/api/interviews/$currentInterviewId/chat")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "Bearer $currentChatToken")
        }

        try {
            validate(connection)
            val responseBody = readResponse(connection)
            val json = JSONObject(responseBody)

            val messagesArray = json.getJSONArray("messages")
            val messages = mutableListOf<String>()

            for (i in 0 until messagesArray.length()) {
                val msg = messagesArray.getJSONObject(i)
                if (!msg.optBoolean("isParticipant", false)) {
                    messages.add(msg.getString("content"))
                }
            }

            messages
        } finally {
            connection.disconnect()
        }
    }

    override suspend fun uploadReplayFrames(
        participantId: String,
        metadata: JSONObject,
        frames: List<ReplayFrame>
    ) = withContext(Dispatchers.IO) {
        val boundary = "UXRateReplayBoundary"
        val url = URL("$baseURL/api/sdk/replay")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            val currentApiKey = synchronized(this@LiveSurveyService) { apiKey }
            if (currentApiKey != null) {
                setRequestProperty("Authorization", "Bearer $currentApiKey")
            }
            doOutput = true
        }

        try {
            val outputStream = DataOutputStream(connection.outputStream)

            // Write metadata part
            outputStream.writeBytes("--$boundary\r\n")
            outputStream.writeBytes("Content-Disposition: form-data; name=\"metadata\"\r\n")
            outputStream.writeBytes("Content-Type: application/json\r\n\r\n")
            outputStream.writeBytes(metadata.toString())
            outputStream.writeBytes("\r\n")

            // Write each frame as a file part
            frames.forEachIndexed { index, frame ->
                outputStream.writeBytes("--$boundary\r\n")
                outputStream.writeBytes(
                    "Content-Disposition: form-data; name=\"frame_$index\"; filename=\"frame_$index.jpg\"\r\n"
                )
                outputStream.writeBytes("Content-Type: image/jpeg\r\n\r\n")
                outputStream.write(frame.imageData)
                outputStream.writeBytes("\r\n")
            }

            outputStream.writeBytes("--$boundary--\r\n")
            outputStream.flush()
            outputStream.close()

            validate(connection)
        } finally {
            connection.disconnect()
        }
    }

    // MARK: - Config Mapping

    private fun mapToSDKConfig(response: StudiesResponse): SDKConfig {
        val surveys = response.studies
            .filter { it.isActive && it.platform == "android" }
            .map { study ->
                SurveyConfig(
                    surveyId = study.id,
                    name = study.name,
                    triggers = listOf(mapScreensTrigger(study.targetTrigger)),
                    triggerLogic = "AND",
                    frequency = FrequencyConfig(
                        maxPerUser = 99,
                        cooldownDays = 0,
                        maxPerSession = 99
                    ),
                    appearance = AppearanceConfig(
                        headline = study.appearance.headline,
                        subtext = study.appearance.subtext,
                        callToAction = study.appearance.callToAction,
                        position = BannerPosition.from(study.appearance.position)
                    ),
                    replayConfig = study.replayConfig
                )
            }

        return SDKConfig(
            surveys = surveys,
            settings = GlobalSettings(maxSurveysPerDay = 99),
            cacheExpiresAt = Date(System.currentTimeMillis() + 3600_000) // 1 hour
        )
    }

    /**
     * Maps screen trigger entries to a single regex alternation pattern.
     * Same logic as iOS:
     *   "name" type → ^Pattern.quote(value)$
     *   "contains" type → .*Pattern.quote(value).*
     *   "regex" type → raw value
     *   empty value → .* (match all)
     *   Multiple entries joined with |
     */
    private fun mapScreensTrigger(targetTrigger: TargetTrigger?): TriggerRule {
        val screens = targetTrigger?.screens
        if (screens.isNullOrEmpty()) {
            return TriggerRule(
                type = "page_visit",
                conditions = mapOf("pagePattern" to CodableValue.StringValue(".*"))
            )
        }

        val patterns = screens.map { screen ->
            if (screen.value.isEmpty()) {
                ".*"
            } else {
                when (screen.matchType) {
                    "name" -> "^${Pattern.quote(screen.value)}$"
                    "contains" -> ".*${Pattern.quote(screen.value)}.*"
                    "regex" -> screen.value
                    else -> ".*"
                }
            }
        }

        val combined = patterns.joinToString("|")

        return TriggerRule(
            type = "page_visit",
            conditions = mapOf("pagePattern" to CodableValue.StringValue(combined))
        )
    }

    // MARK: - HTTP Helpers

    private fun validate(connection: HttpURLConnection) {
        val statusCode = connection.responseCode
        if (statusCode !in 200..299) {
            throw LiveSurveyError.HttpError(statusCode)
        }
    }

    private fun readResponse(connection: HttpURLConnection): String {
        return BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
            reader.readText()
        }
    }

    private fun writeBody(connection: HttpURLConnection, body: String) {
        OutputStreamWriter(connection.outputStream).use { writer ->
            writer.write(body)
            writer.flush()
        }
    }

    // MARK: - Error Types

    sealed class LiveSurveyError : Exception() {
        object NotConfigured : LiveSurveyError() {
            private fun readResolve(): Any = NotConfigured
            override val message: String = "LiveSurveyService has not been configured yet."
        }

        data class HttpError(val statusCode: Int) : LiveSurveyError() {
            override val message: String = "HTTP error $statusCode."
        }
    }
}
