package com.uxrate.sdk.services

import android.util.Log
import com.uxrate.sdk.UXRate
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Event item tracked by the SDK.
 * Serialized to JSON for backend submission.
 */
data class SdkEventItem(
    val type: String,
    val timestamp: String,
    val name: String? = null,
    val properties: Map<String, Any>? = null,
    val studyId: String? = null,
    val count: Int = 1
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("type", type)
            put("timestamp", timestamp)
            if (name != null) put("name", name)
            if (properties != null) {
                put("properties", JSONObject(properties))
            }
            if (studyId != null) put("studyId", studyId)
            put("count", count)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): SdkEventItem {
            val props = if (json.has("properties") && !json.isNull("properties")) {
                val propsJson = json.getJSONObject("properties")
                val map = mutableMapOf<String, Any>()
                propsJson.keys().forEach { key ->
                    map[key] = propsJson.get(key)
                }
                map
            } else null

            return SdkEventItem(
                type = json.getString("type"),
                timestamp = json.getString("timestamp"),
                name = json.optString("name", null),
                properties = props,
                studyId = json.optString("studyId", null),
                count = json.optInt("count", 1)
            )
        }

        /**
         * Returns the current time as an ISO 8601 string.
         */
        fun nowTimestamp(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            return sdf.format(Date())
        }
    }
}

/**
 * In-memory event queue that batches SDK events and flushes them to the backend.
 * Persists unsent events to LocalStorage on flush failure so they survive app restarts.
 *
 * Thread-safe via synchronized blocks (matching existing SDK pattern).
 */
class EventQueue(
    private val service: SurveyService,
    private val storage: LocalStorage,
    private val participantId: String
) {
    companion object {
        private const val TAG = "UXRate"
        private const val FLUSH_THRESHOLD = 50
    }

    private val lock = Any()
    private val events = mutableListOf<SdkEventItem>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * Loads any persisted events from a previous session.
     * Call once during SDK configuration.
     */
    fun loadPersistedEvents() {
        synchronized(lock) {
            val json = storage.loadAndClearPendingEvents() ?: return
            try {
                val array = JSONArray(json)
                for (i in 0 until array.length()) {
                    events.add(SdkEventItem.fromJson(array.getJSONObject(i)))
                }
                if (UXRate.loggingEnabled && events.isNotEmpty()) {
                    Log.d(TAG, "Loaded ${events.size} persisted events from previous session")
                }
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to load persisted events: ${e.message}")
                }
            }
        }
    }

    /**
     * Adds an event to the queue. Auto-flushes when the queue reaches the threshold.
     */
    fun enqueue(event: SdkEventItem) {
        val shouldFlush: Boolean
        synchronized(lock) {
            events.add(event)
            shouldFlush = events.size >= FLUSH_THRESHOLD

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Event enqueued: type=${event.type}, name=${event.name}, queue size=${events.size}")
            }
        }

        if (shouldFlush) {
            flush()
        }
    }

    /**
     * Flushes all queued events to the backend.
     * On failure, persists events to LocalStorage for retry on next session.
     */
    fun flush() {
        val snapshot: List<SdkEventItem>
        synchronized(lock) {
            if (events.isEmpty()) return
            snapshot = events.toList()
            events.clear()
        }

        scope.launch {
            try {
                service.sendEvents(participantId, snapshot)

                if (UXRate.loggingEnabled) {
                    Log.d(TAG, "Flushed ${snapshot.size} events to backend")
                }
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to flush events, persisting to storage: ${e.message}")
                }
                // Persist to storage so events are not lost
                persistEvents(snapshot)
            }
        }
    }

    private fun persistEvents(eventsToSave: List<SdkEventItem>) {
        synchronized(lock) {
            // Merge with any events that were queued while flushing
            val allEvents = eventsToSave + events.toList()
            val array = JSONArray()
            allEvents.forEach { array.put(it.toJson()) }
            storage.savePendingEvents(array.toString())
        }
    }
}
