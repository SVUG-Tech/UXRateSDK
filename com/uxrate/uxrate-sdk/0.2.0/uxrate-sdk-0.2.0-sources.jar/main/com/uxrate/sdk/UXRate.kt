package com.uxrate.sdk

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.uxrate.sdk.models.OverlapStrategy
import com.uxrate.sdk.models.SDKTheme
import com.uxrate.sdk.services.EventQueue
import com.uxrate.sdk.services.LiveSurveyService
import com.uxrate.sdk.services.LocalStorage
import com.uxrate.sdk.services.MockSurveyService
import com.uxrate.sdk.ui.SurveyChatActivity
import com.uxrate.sdk.ui.SurveyOverlayManager
import kotlinx.coroutines.*
import java.lang.ref.WeakReference

/**
 * Public API entry point for the UXRate SDK.
 * Maps to iOS @MainActor enum UXRate.
 *
 * Usage:
 *   UXRate.configure(application, apiKey = "uxr_xxx")
 *   UXRate.identify(userId = "user-123", properties = mapOf("tier" to "premium"))
 *   UXRate.track(event = "purchase_complete")
 *   UXRate.setScreen(name = "Checkout")
 */
object UXRate {

    private const val TAG = "UXRate"

    /**
     * Enable/disable logging. Defaults to BuildConfig.DEBUG equivalent.
     */
    var loggingEnabled: Boolean = false

    /**
     * Internal reference to the SurveyManager singleton.
     * Accessible by SurveyChatActivity.
     */
    internal var surveyManager: SurveyManager? = null

    private var application: Application? = null
    internal var currentActivityRef: WeakReference<Activity>? = null

    /** The currently resumed Activity, if any. */
    internal val currentActivity: Activity? get() = currentActivityRef?.get()
    private var lifecycleCallbacks: Application.ActivityLifecycleCallbacks? = null
    private var autoTrackScreens: Boolean = true

    // Coroutine scope for configuration
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /**
     * Configures the UXRate SDK.
     * Maps to iOS UXRate.configure(apiKey:baseURL:autoTrackScreens:useMockService:overlapStrategy:theme:)
     *
     * @param application The Android Application instance
     * @param apiKey The SDK API key (uxr_* token)
     * @param baseURL Backend root URL (default: https://app.uxrate.com)
     * @param autoTrackScreens Auto-track Activity names (default: true)
     * @param useMockService Use mock service for development (default: false)
     * @param overlapStrategy How to resolve multiple matching surveys (default: SHOW_FIRST)
     * @param theme Color scheme override (default: AUTO)
     */
    fun configure(
        application: Application,
        apiKey: String,
        baseURL: String = "https://app.uxrate.com",
        autoTrackScreens: Boolean = true,
        useMockService: Boolean = false,
        overlapStrategy: OverlapStrategy = OverlapStrategy.SHOW_FIRST,
        theme: SDKTheme = SDKTheme.AUTO
    ) {
        this.application = application
        this.autoTrackScreens = autoTrackScreens

        val storage = LocalStorage(application)

        val service = if (useMockService) {
            MockSurveyService()
        } else {
            LiveSurveyService(
                baseURL = baseURL,
                participantId = storage.participantId
            )
        }

        val eventQueue = EventQueue(
            service = service,
            storage = storage,
            participantId = storage.participantId
        )

        // Load any persisted events from previous sessions
        eventQueue.loadPersistedEvents()

        val manager = SurveyManager(
            service = service,
            storage = storage,
            overlapStrategy = overlapStrategy,
            theme = theme,
            eventQueue = eventQueue,
            baseURL = baseURL
        )
        surveyManager = manager

        // Register Activity lifecycle callbacks for auto screen tracking and overlay management
        registerLifecycleCallbacks(application, manager)

        // Async: fetch configuration
        scope.launch {
            manager.configure(apiKey)
        }

        if (loggingEnabled) {
            Log.d(TAG, "UXRate SDK configured (autoTrack=$autoTrackScreens, mock=$useMockService)")
        }
    }

    /**
     * Identifies the current user for segment targeting.
     * Maps to iOS UXRate.identify(userId:properties:)
     */
    fun identify(userId: String, properties: Map<String, String> = emptyMap()) {
        surveyManager?.identify(userId, properties)
    }

    /**
     * Tracks a custom event and re-evaluates trigger rules.
     * Maps to iOS UXRate.track(event:properties:)
     */
    fun track(event: String, properties: Map<String, String> = emptyMap()) {
        surveyManager?.track(event, properties)
    }

    /**
     * Manually sets the current screen name for trigger evaluation.
     * Overrides auto-tracking for the current screen.
     * Maps to iOS UXRate.setScreen(name:)
     */
    fun setScreen(name: String) {
        val manager = surveyManager ?: return

        // Signal the lifecycle callback to skip its own call
        manager.pendingManualScreen = name
        manager.setCurrentScreen(name)
    }

    /**
     * Clears the current screen, hiding any visible banner.
     * Called internally by SurveyScreen() on dispose.
     */
    internal fun clearScreen(name: String) {
        surveyManager?.clearScreen(name)
    }

    // MARK: - Internal

    /**
     * Launches the SurveyChatActivity from the current Activity.
     */
    internal fun launchChatActivity() {
        val activity = currentActivityRef?.get() ?: return
        val intent = Intent(activity, SurveyChatActivity::class.java)
        activity.startActivity(intent)
    }

    // MARK: - Lifecycle Callbacks

    /**
     * Registers Activity lifecycle callbacks for:
     * 1. Auto screen tracking (onActivityResumed)
     * 2. Overlay management (attach/detach ComposeView)
     *
     * Maps to iOS UIViewController swizzle + didBecomeActiveNotification
     */
    private fun registerLifecycleCallbacks(
        application: Application,
        manager: SurveyManager
    ) {
        // Unregister previous callbacks if re-configuring
        lifecycleCallbacks?.let { application.unregisterActivityLifecycleCallbacks(it) }

        val callbacks = object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                currentActivityRef = WeakReference(activity)

                // Skip SurveyChatActivity for overlay and screen tracking
                if (activity is SurveyChatActivity) return

                // Attach overlay to the current activity
                SurveyOverlayManager.attachOverlay(activity, manager)

                // Auto screen tracking
                if (autoTrackScreens) {
                    val pendingManual = manager.pendingManualScreen
                    if (pendingManual != null) {
                        // Developer called setScreen() — clear the flag, skip auto-tracking
                        manager.pendingManualScreen = null
                    } else {
                        // Auto-generate screen name from Activity class
                        val screenName = extractScreenName(activity)
                        if (screenName != null) {
                            manager.setCurrentScreen(screenName)
                        }
                    }
                }

                // Resume replay capture if configured (idempotent — no-op if already capturing)
                // For "triggered" mode, capture starts only after activateCapture()
                manager.replayCapture?.let { capture ->
                    if (capture.shouldCapture()) {
                        capture.startCapturing(activity)
                    }
                }
            }

            override fun onActivityPaused(activity: Activity) {
                // Detach overlay when activity is paused (but not for chat activity)
                if (activity !is SurveyChatActivity) {
                    // Don't detach here — let attachOverlay handle the switch
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {
                // Skip config changes (rotation, etc.)
                val isConfigChange = activity.isChangingConfigurations
                if (!isConfigChange) {
                    // Flush events when activity stops
                    manager.eventQueue?.flush()

                    // Flush replay buffer without stopping capture
                    // Recording resumes automatically on next onActivityResumed
                    if (activity !is SurveyChatActivity) {
                        manager.flushReplay()
                    }
                }
            }
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {
                if (activity == currentActivityRef?.get()) {
                    SurveyOverlayManager.detachOverlay()
                }
            }
        }

        application.registerActivityLifecycleCallbacks(callbacks)
        lifecycleCallbacks = callbacks
    }

    /**
     * Extracts a clean screen name from an Activity class name.
     * Maps to iOS uxrate_viewDidAppear class name extraction.
     *
     * Removes "Activity" suffix and filters out system/framework activities.
     */
    private fun extractScreenName(activity: Activity): String? {
        val className = activity.javaClass.simpleName

        // Skip system and framework activities
        val skipPrefixes = listOf(
            "SurveyChatActivity",
            "Navigation",
            "Splash"
        )
        if (skipPrefixes.any { className.startsWith(it) }) return null

        // Remove "Activity" suffix for cleaner names
        return className
            .removeSuffix("Activity")
            .removeSuffix("Fragment")
            .ifEmpty { null }
    }
}
