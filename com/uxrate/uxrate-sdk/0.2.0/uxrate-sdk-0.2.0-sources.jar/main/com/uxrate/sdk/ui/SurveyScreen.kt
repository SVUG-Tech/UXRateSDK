package com.uxrate.sdk.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.uxrate.sdk.UXRate

/**
 * Composable that reports a screen name to the UXRate SDK.
 * Equivalent to iOS `.surveyScreen("Home")` modifier.
 *
 * Reports the screen on enter and clears it on leave — so the banner
 * automatically hides when navigating to a screen without SurveyScreen().
 *
 * ```kotlin
 * @Composable
 * fun HomeScreen() {
 *     SurveyScreen("Home")
 *     // ... rest of your UI
 * }
 * ```
 */
@Composable
fun SurveyScreen(name: String) {
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(name, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> UXRate.setScreen(name)
                Lifecycle.Event.ON_PAUSE -> UXRate.clearScreen(name)
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        // Don't call setScreen here — ON_RESUME fires immediately after
        // composition, so calling it here would double-increment visit count.
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            UXRate.clearScreen(name)
        }
    }
}
