package com.uxrate.sdk.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.uxrate.sdk.models.SDKTheme

/**
 * UXRate SDK color definitions and theme wrapper.
 * Maps exact hex values from iOS SDK.
 */
object UXRateColors {
    // Banner card background
    val bannerBackgroundLight = Color.White
    val bannerBackgroundDark = Color(0xFF1D293D)

    // CTA button
    val ctaBackgroundLight = Color(0xFF1A1E40) // dark navy
    val ctaTextLight = Color.White
    val ctaBackgroundDark = Color.White
    val ctaTextDark = Color(0xFF1A1E40)

    // Close button
    val closeButtonCircleDark = Color(0xFF314158)
    val closeButtonIconDark = Color.White.copy(alpha = 0.7f)

    // Banner text
    val bannerSubtextDarkAlpha = 0.7f

    // Shadow
    val shadowLight = Color.Black.copy(alpha = 0.1f)
    val shadowDark = Color.Black.copy(alpha = 0.4f)

    // Border
    val borderLight = Color.Gray.copy(alpha = 0.15f)
    val borderDark = Color.Gray.copy(alpha = 0.3f)

    // Chat bubbles
    val userBubbleBackground = Color(0xFF007AFF) // System blue
    val userBubbleText = Color.White
    val assistantBubbleBackground = Color.Gray.copy(alpha = 0.15f)

    // Typing indicator
    val typingDotColor = Color.Gray.copy(alpha = 0.5f)
    val typingBackground = Color.Gray.copy(alpha = 0.15f)

    // Input field
    val inputFieldBackground = Color.Gray.copy(alpha = 0.1f)
    val sendButtonActive = Color(0xFF007AFF) // System blue
    val sendButtonInactive = Color.Gray

    // Return to app button
    val returnButtonBackground = Color(0xFF34C759) // System green
}

private val LightColorScheme = lightColorScheme()
private val DarkColorScheme = darkColorScheme()

@Composable
fun UXRateTheme(
    sdkTheme: SDKTheme = SDKTheme.AUTO,
    content: @Composable () -> Unit
) {
    val isDark = when (sdkTheme) {
        SDKTheme.AUTO -> isSystemInDarkTheme()
        SDKTheme.LIGHT -> false
        SDKTheme.DARK -> true
    }

    MaterialTheme(
        colorScheme = if (isDark) DarkColorScheme else LightColorScheme,
        content = content
    )
}

/**
 * Helper to resolve dark mode based on SDK theme setting.
 */
@Composable
fun resolveIsDark(sdkTheme: SDKTheme): Boolean {
    return when (sdkTheme) {
        SDKTheme.AUTO -> isSystemInDarkTheme()
        SDKTheme.LIGHT -> false
        SDKTheme.DARK -> true
    }
}
