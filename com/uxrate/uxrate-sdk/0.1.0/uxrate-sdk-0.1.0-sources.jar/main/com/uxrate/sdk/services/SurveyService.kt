package com.uxrate.sdk.services

import com.uxrate.sdk.models.ChatMessage
import com.uxrate.sdk.models.ChatReply
import com.uxrate.sdk.models.SDKConfig

/**
 * Interface for survey service implementations.
 * Maps to iOS SurveyServiceProtocol.
 */
interface SurveyService {

    /**
     * Fetches full SDK configuration from the backend.
     * @param apiKey The SDK API key (uxr_* token)
     * @return SDKConfig with all surveys, triggers, and appearance settings
     */
    suspend fun fetchConfiguration(apiKey: String): SDKConfig

    /**
     * Creates an interview session on the backend and fetches initial AI messages.
     * @return List of AI opening message strings in order
     */
    suspend fun createSession(): List<String>

    /**
     * Sends a user message and returns the AI reply.
     * @param message The user's message text
     * @param conversationHistory Full conversation history for context
     * @return ChatReply with AI response content and isCompleted flag
     */
    suspend fun sendMessage(message: String, conversationHistory: List<ChatMessage>): ChatReply
}
