package com.uxrate.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.uxrate.sdk.ui.theme.UXRateColors

/**
 * Chat input bar with text field and send button.
 * Maps to iOS ChatInputBar.
 *
 * TextField: gray 10% bg, 20dp radius, 12dp/8dp padding
 * Send button: 32dp, arrow icon, blue/gray
 */
@Composable
fun ChatInputBar(
    isDisabled: Boolean,
    onSend: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val canSend = text.isNotBlank() && !isDisabled

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Text field
        TextField(
            value = text,
            onValueChange = { text = it },
            placeholder = { Text("Type a message...") },
            enabled = !isDisabled,
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(20.dp)),
            colors = TextFieldDefaults.colors(
                unfocusedContainerColor = UXRateColors.inputFieldBackground,
                focusedContainerColor = UXRateColors.inputFieldBackground,
                disabledContainerColor = UXRateColors.inputFieldBackground,
                unfocusedIndicatorColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent
            ),
            maxLines = 5,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(
                onSend = {
                    if (canSend) {
                        val trimmed = text.trim()
                        text = ""
                        onSend(trimmed)
                    }
                }
            )
        )

        // Send button
        IconButton(
            onClick = {
                if (canSend) {
                    val trimmed = text.trim()
                    text = ""
                    onSend(trimmed)
                }
            },
            enabled = canSend,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.KeyboardArrowUp,
                contentDescription = "Send",
                tint = if (canSend) UXRateColors.sendButtonActive else UXRateColors.sendButtonInactive,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(
                        if (canSend) UXRateColors.sendButtonActive.copy(alpha = 0.1f)
                        else Color.Transparent
                    )
                    .padding(4.dp)
            )
        }
    }
}
