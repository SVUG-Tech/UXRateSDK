package com.uxrate.sdk.services

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Persistence layer using SharedPreferences.
 * Maps to iOS LocalStorage class.
 * Thread-safe via synchronized blocks.
 */
class LocalStorage(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("uxrate_sdk", Context.MODE_PRIVATE)

    private val lock = Any()

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    companion object {
        // Key prefixes matching iOS key scheme
        private const val KEY_VISITS = "uxrate.visits."
        private const val KEY_EVENTS = "uxrate.events."
        private const val KEY_INSTALL_DATE = "uxrate.installDate"
        private const val KEY_LAST_SHOWN = "uxrate.lastShown."
        private const val KEY_COMPLETED = "uxrate.completed."
        private const val KEY_USER_PROPERTIES = "uxrate.userProperties"
        private const val KEY_USER_ID = "uxrate.userId"
        private const val KEY_PARTICIPANT_ID = "uxrate.participantId"
        private const val KEY_CONFIG_CACHE = "uxrate.configCache"
        private const val KEY_CONFIG_CACHE_EXPIRY = "uxrate.configCacheExpiry"
        private const val KEY_DAILY_COUNT = "uxrate.dailyCount."
    }

    // MARK: - Participant ID

    val participantId: String
        get() = synchronized(lock) {
            prefs.getString(KEY_PARTICIPANT_ID, null) ?: run {
                val newId = UUID.randomUUID().toString()
                prefs.edit().putString(KEY_PARTICIPANT_ID, newId).apply()
                newId
            }
        }

    // MARK: - Install Date

    val installDate: Date
        get() = synchronized(lock) {
            val timestamp = prefs.getLong(KEY_INSTALL_DATE, 0L)
            if (timestamp != 0L) {
                Date(timestamp)
            } else {
                val now = Date()
                prefs.edit().putLong(KEY_INSTALL_DATE, now.time).apply()
                now
            }
        }

    // MARK: - Visit Counts

    fun visitCount(screenName: String): Int = synchronized(lock) {
        prefs.getInt("$KEY_VISITS$screenName", 0)
    }

    fun incrementVisit(screenName: String) = synchronized(lock) {
        val current = prefs.getInt("$KEY_VISITS$screenName", 0)
        prefs.edit().putInt("$KEY_VISITS$screenName", current + 1).apply()
    }

    // MARK: - Event Counts

    fun eventCount(eventName: String): Int = synchronized(lock) {
        prefs.getInt("$KEY_EVENTS$eventName", 0)
    }

    fun incrementEvent(eventName: String) = synchronized(lock) {
        val current = prefs.getInt("$KEY_EVENTS$eventName", 0)
        prefs.edit().putInt("$KEY_EVENTS$eventName", current + 1).apply()
    }

    // MARK: - Survey Tracking

    fun lastShownDate(surveyId: String): Date? = synchronized(lock) {
        val timestamp = prefs.getLong("$KEY_LAST_SHOWN$surveyId", 0L)
        if (timestamp != 0L) Date(timestamp) else null
    }

    fun recordShown(surveyId: String) = synchronized(lock) {
        prefs.edit().putLong("$KEY_LAST_SHOWN$surveyId", System.currentTimeMillis()).apply()
    }

    fun completedCount(surveyId: String): Int = synchronized(lock) {
        prefs.getInt("$KEY_COMPLETED$surveyId", 0)
    }

    fun recordCompleted(surveyId: String) = synchronized(lock) {
        val current = prefs.getInt("$KEY_COMPLETED$surveyId", 0)
        prefs.edit().putInt("$KEY_COMPLETED$surveyId", current + 1).apply()
    }

    // MARK: - User Properties

    fun getUserProperties(): Map<String, String> = synchronized(lock) {
        val result = mutableMapOf<String, String>()
        val propsString = prefs.getString(KEY_USER_PROPERTIES, null) ?: return@synchronized result
        // Simple key=value pairs separated by \n
        propsString.split("\n").forEach { line ->
            val parts = line.split("=", limit = 2)
            if (parts.size == 2) {
                result[parts[0]] = parts[1]
            }
        }
        result
    }

    fun setUserProperties(properties: Map<String, String>) = synchronized(lock) {
        val existing = getUserProperties().toMutableMap()
        existing.putAll(properties)
        val encoded = existing.entries.joinToString("\n") { "${it.key}=${it.value}" }
        prefs.edit().putString(KEY_USER_PROPERTIES, encoded).apply()
    }

    fun setUserId(userId: String) = synchronized(lock) {
        prefs.edit().putString(KEY_USER_ID, userId).apply()
    }

    fun getUserId(): String? = synchronized(lock) {
        prefs.getString(KEY_USER_ID, null)
    }

    // MARK: - Config Cache

    fun getCachedConfigData(): String? = synchronized(lock) {
        prefs.getString(KEY_CONFIG_CACHE, null)
    }

    fun getConfigCacheExpiry(): Date? = synchronized(lock) {
        val timestamp = prefs.getLong(KEY_CONFIG_CACHE_EXPIRY, 0L)
        if (timestamp != 0L) Date(timestamp) else null
    }

    fun saveConfigCache(data: String, expiry: Date) = synchronized(lock) {
        prefs.edit()
            .putString(KEY_CONFIG_CACHE, data)
            .putLong(KEY_CONFIG_CACHE_EXPIRY, expiry.time)
            .apply()
    }

    // MARK: - Daily Survey Count

    fun todaySurveyCount(): Int = synchronized(lock) {
        val todayKey = "$KEY_DAILY_COUNT${dateFormat.format(Date())}"
        prefs.getInt(todayKey, 0)
    }

    fun incrementTodaySurveyCount() = synchronized(lock) {
        val todayKey = "$KEY_DAILY_COUNT${dateFormat.format(Date())}"
        val current = prefs.getInt(todayKey, 0)
        prefs.edit().putInt(todayKey, current + 1).apply()
    }
}
