package com.uxrate.sdk

import android.util.Log
import com.uxrate.sdk.models.*
import com.uxrate.sdk.services.LocalStorage
import com.uxrate.sdk.services.SurveyService
import com.uxrate.sdk.services.TriggerEvaluator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Central state manager for the UXRate SDK.
 * Maps to iOS SurveyManager (@Observable class).
 *
 * Uses MutableStateFlow for reactive state (equivalent to SwiftUI @Observable).
 * All state mutations dispatched on Main thread.
 */
class SurveyManager(
    private val service: SurveyService,
    val storage: LocalStorage,
    val overlapStrategy: OverlapStrategy,
    val theme: SDKTheme
) {
    companion object {
        private const val TAG = "UXRate"
    }

    // Coroutine scope for async operations
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // MARK: - Configuration State

    private var isConfigured = false
    private var sdkConfig: SDKConfig? = null

    // MARK: - Screen Tracking

    private var currentScreen: String? = null
    var pendingManualScreen: String? = null

    // MARK: - Survey State

    private val _activeSurveyState = MutableStateFlow<ActiveSurveyState?>(null)
    val activeSurveyState: StateFlow<ActiveSurveyState?> = _activeSurveyState.asStateFlow()

    private val _shouldShowBanner = MutableStateFlow(false)
    val shouldShowBanner: StateFlow<Boolean> = _shouldShowBanner.asStateFlow()

    private val dismissedScreens = mutableSetOf<String>()

    // MARK: - Chat State

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoadingResponse = MutableStateFlow(false)
    val isLoadingResponse: StateFlow<Boolean> = _isLoadingResponse.asStateFlow()

    private val _isChatCompleted = MutableStateFlow(false)
    val isChatCompleted: StateFlow<Boolean> = _isChatCompleted.asStateFlow()

    private val _isChatPresented = MutableStateFlow(false)
    val isChatPresented: StateFlow<Boolean> = _isChatPresented.asStateFlow()

    // MARK: - Frequency Tracking

    private var sessionSurveyCount = 0
    private val evaluator = TriggerEvaluator(storage)

    // MARK: - Core Methods

    /**
     * Fetches configuration from the backend and marks SDK as configured.
     * Maps to iOS SurveyManager.configure(apiKey:)
     */
    suspend fun configure(apiKey: String) {
        sessionSurveyCount = 0

        try {
            val config = service.fetchConfiguration(apiKey)
            sdkConfig = config
            isConfigured = true

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "SDK configured with ${config.surveys.size} surveys")
            }

            // Evaluate in case screen tracking already fired before config was ready
            evaluateAndShow()
        } catch (e: Exception) {
            if (UXRate.loggingEnabled) {
                Log.e(TAG, "Failed to configure SDK: ${e.message}")
            }
        }
    }

    /**
     * Sets the current screen and re-evaluates trigger rules.
     * Maps to iOS SurveyManager.setCurrentScreen(_:)
     */
    fun setCurrentScreen(screenName: String) {
        val previousScreen = currentScreen
        currentScreen = screenName

        // Increment visit count
        storage.incrementVisit(screenName)

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Screen: $screenName (visits: ${storage.visitCount(screenName)}, configured: $isConfigured)")
        }

        // Only re-evaluate if screen actually changed
        if (screenName != previousScreen) {
            evaluateAndShow()
        }
    }

    /**
     * Core trigger evaluation and display logic.
     * Maps to iOS SurveyManager.evaluateAndShow()
     */
    private fun evaluateAndShow() {
        // Guard: must be configured, have config, and have current screen
        if (!isConfigured) return
        val config = sdkConfig ?: return
        val screen = currentScreen ?: return

        // Guard: no chat already presented
        if (_isChatPresented.value) return

        // Check daily cap
        if (storage.todaySurveyCount() >= config.settings.maxSurveysPerDay) {
            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Daily survey cap reached")
            }
            return
        }

        // Get all matching surveys
        val matches = evaluator.matchingSurveys(screen, config, sessionSurveyCount)

        if (UXRate.loggingEnabled) {
            Log.d(TAG, "Found ${matches.size} matching surveys for screen '$screen'")
        }

        // Apply overlap strategy
        val selectedSurvey = resolve(matches)

        if (selectedSurvey != null && !dismissedScreens.contains(screen)) {
            _activeSurveyState.value = ActiveSurveyState(
                sdkConfig = config,
                activeSurvey = selectedSurvey
            )
            _shouldShowBanner.value = true

            if (UXRate.loggingEnabled) {
                Log.d(TAG, "Showing banner for survey: ${selectedSurvey.name}")
            }
        } else {
            _shouldShowBanner.value = false
        }
    }

    /**
     * Resolves multiple matching surveys using the configured overlap strategy.
     * Maps to iOS SurveyManager.resolve(matches:)
     */
    private fun resolve(matches: List<SurveyConfig>): SurveyConfig? {
        if (matches.isEmpty()) return null

        return when (overlapStrategy) {
            OverlapStrategy.SHOW_FIRST -> matches.first()
            OverlapStrategy.SHOW_LAST -> matches.last()
            OverlapStrategy.SHOW_RANDOM -> matches.random()
            OverlapStrategy.SHOW_NONE -> if (matches.size == 1) matches.first() else null
        }
    }

    /**
     * Dismisses the banner for the current screen.
     * Maps to iOS SurveyManager.dismissBanner()
     */
    fun dismissBanner() {
        currentScreen?.let { dismissedScreens.add(it) }
        _shouldShowBanner.value = false
    }

    /**
     * Opens the chat for the active survey.
     * Maps to iOS SurveyManager.openChat()
     */
    fun openChat() {
        val surveyState = _activeSurveyState.value ?: return

        // Record survey as shown
        storage.recordShown(surveyState.surveyId)
        storage.incrementTodaySurveyCount()
        sessionSurveyCount++

        // Reset chat state
        _shouldShowBanner.value = false
        _isChatCompleted.value = false
        _messages.value = emptyList()
        _isChatPresented.value = true

        // Launch chat activity
        UXRate.launchChatActivity()

        // Fetch initial messages
        scope.launch {
            _isLoadingResponse.value = true
            try {
                val initialMessages = service.createSession()
                val chatMessages = initialMessages.map { content ->
                    ChatMessage(
                        content = content,
                        role = ChatMessage.Role.ASSISTANT
                    )
                }
                _messages.value = chatMessages
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to create chat session: ${e.message}")
                }
                _messages.value = listOf(
                    ChatMessage(
                        content = "Sorry, we couldn't start the survey. Please try again later.",
                        role = ChatMessage.Role.ASSISTANT
                    )
                )
            } finally {
                _isLoadingResponse.value = false
            }
        }
    }

    /**
     * Sends a user message and handles the AI reply.
     * Maps to iOS SurveyManager.sendMessage(text:)
     */
    fun sendMessage(text: String) {
        val userMessage = ChatMessage(
            content = text,
            role = ChatMessage.Role.USER
        )
        _messages.value = _messages.value + userMessage
        _isLoadingResponse.value = true

        scope.launch {
            try {
                val reply = service.sendMessage(text, _messages.value)
                val assistantMessage = ChatMessage(
                    content = reply.content,
                    role = ChatMessage.Role.ASSISTANT
                )
                _messages.value = _messages.value + assistantMessage

                if (reply.isCompleted) {
                    val surveyId = _activeSurveyState.value?.surveyId
                    if (surveyId != null) {
                        storage.recordCompleted(surveyId)
                    }
                    _isChatCompleted.value = true
                }
            } catch (e: Exception) {
                if (UXRate.loggingEnabled) {
                    Log.e(TAG, "Failed to send message: ${e.message}")
                }
                val errorMessage = ChatMessage(
                    content = "Sorry, something went wrong. Please try again.",
                    role = ChatMessage.Role.ASSISTANT
                )
                _messages.value = _messages.value + errorMessage
            } finally {
                _isLoadingResponse.value = false
            }
        }
    }

    /**
     * Called when chat is dismissed (by user or system).
     */
    fun onChatDismissed() {
        _isChatPresented.value = false
    }

    /**
     * Stores user identification info for segment targeting.
     * Maps to iOS SurveyManager.identify(userId:properties:)
     */
    fun identify(userId: String, properties: Map<String, String>) {
        storage.setUserId(userId)
        if (properties.isNotEmpty()) {
            storage.setUserProperties(properties)
        }
    }

    /**
     * Tracks a custom event and re-evaluates trigger rules.
     * Maps to iOS SurveyManager.track(event:properties:)
     */
    fun track(event: String, properties: Map<String, String>) {
        storage.incrementEvent(event)
        evaluateAndShow()
    }
}
