package com.uxrate.sdk.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.uxrate.sdk.ui.theme.UXRateColors
import kotlinx.coroutines.delay

/**
 * Typing indicator with 3 animated dots.
 * Maps to iOS TypingIndicatorView.
 *
 * 3 dots (8dp), gray 50%, 4dp spacing
 * Sequential bounce 4dp up, 300ms cycle per dot, easeInOut
 */
@Composable
fun TypingIndicator() {
    var animationPhase by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(300)
            animationPhase = (animationPhase + 1) % 3
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
    ) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(UXRateColors.typingBackground)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            repeat(3) { index ->
                TypingDot(isActive = index == animationPhase)
            }
        }
        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
private fun TypingDot(isActive: Boolean) {
    val offsetY by animateFloatAsState(
        targetValue = if (isActive) -4f else 0f,
        animationSpec = tween(
            durationMillis = 300,
            easing = FastOutSlowInEasing
        ),
        label = "dotBounce"
    )

    Box(
        modifier = Modifier
            .size(8.dp)
            .offset(y = offsetY.dp)
            .clip(CircleShape)
            .background(UXRateColors.typingDotColor)
    )
}
