package com.uxrate.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uxrate.sdk.ui.theme.UXRateColors

/**
 * Survey banner card shown as an overlay.
 * Maps to iOS SurveyFloatingButton (SurveyBannerView).
 *
 * Card: 14dp corner radius, 16dp padding
 * Shadow: 12dp blur, 4dp y-offset
 * Close button: 28dp circle
 * CTA button: 8dp corner radius
 */
@Composable
fun SurveyBannerView(
    headline: String,
    subtext: String,
    callToAction: String,
    isDark: Boolean,
    onStartSurvey: () -> Unit,
    onDismiss: () -> Unit
) {
    val cardBackground = if (isDark) UXRateColors.bannerBackgroundDark else UXRateColors.bannerBackgroundLight
    val headlineColor = if (isDark) Color.White else Color.Black
    val subtextColor = if (isDark) Color.White.copy(alpha = 0.7f) else Color.Gray
    val ctaBackground = if (isDark) UXRateColors.ctaBackgroundDark else UXRateColors.ctaBackgroundLight
    val ctaTextColor = if (isDark) UXRateColors.ctaTextDark else UXRateColors.ctaTextLight
    val shadowColor = if (isDark) UXRateColors.shadowDark else UXRateColors.shadowLight
    val borderColor = if (isDark) UXRateColors.borderDark else UXRateColors.borderLight
    val closeCircleBg = if (isDark) UXRateColors.closeButtonCircleDark else Color.Transparent
    val closeIconColor = if (isDark) UXRateColors.closeButtonIconDark else Color.Gray

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 12.dp,
                shape = RoundedCornerShape(14.dp),
                ambientColor = shadowColor,
                spotColor = shadowColor
            )
            .clip(RoundedCornerShape(14.dp))
            .background(cardBackground)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        // Top section: headline + subtext + close button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = headline,
                    color = headlineColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtext,
                    color = subtextColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal
                )
            }

            // Close button
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(closeCircleBg)
                    .clickable { onDismiss() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Dismiss",
                    tint = closeIconColor,
                    modifier = Modifier.size(14.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // CTA button
        Button(
            onClick = onStartSurvey,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = ctaBackground,
                contentColor = ctaTextColor
            ),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            Text(
                text = callToAction,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
