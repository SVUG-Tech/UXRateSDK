package com.uxrate.sdk.ui

import android.app.Activity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import com.uxrate.sdk.SurveyManager
import com.uxrate.sdk.models.BannerPosition
import com.uxrate.sdk.ui.theme.UXRateTheme
import com.uxrate.sdk.ui.theme.resolveIsDark

/**
 * Manages the banner overlay ComposeView injected into Activity's content FrameLayout.
 * Maps to iOS SurveyWindowOverlay + passthrough UIWindow.
 *
 * On Android, we add a ComposeView to the Activity's android.R.id.content FrameLayout.
 * The ComposeView is transparent and non-interactive except for the banner area.
 */
object SurveyOverlayManager {

    private var currentOverlayView: ComposeView? = null
    private var currentActivity: Activity? = null

    /**
     * Attaches the banner overlay to the given Activity.
     * Called from ActivityLifecycleCallbacks.onActivityResumed.
     */
    fun attachOverlay(activity: Activity, manager: SurveyManager) {
        // Don't attach to SurveyChatActivity
        if (activity is SurveyChatActivity) return

        // Remove from previous activity if different
        if (currentActivity != activity) {
            detachOverlay()
        }

        if (currentOverlayView != null) return // Already attached to this activity

        val contentFrame = activity.findViewById<FrameLayout>(android.R.id.content) ?: return

        val composeView = ComposeView(activity).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            setContent {
                UXRateTheme(sdkTheme = manager.theme) {
                    SurveyOverlayContent(manager = manager)
                }
            }
        }

        contentFrame.addView(composeView)
        currentOverlayView = composeView
        currentActivity = activity
    }

    /**
     * Detaches the banner overlay from the current Activity.
     */
    fun detachOverlay() {
        currentOverlayView?.let { view ->
            (view.parent as? ViewGroup)?.removeView(view)
        }
        currentOverlayView = null
        currentActivity = null
    }
}

/**
 * The actual overlay content composable.
 * Shows/hides banner with slide+fade animation (250ms easeOut).
 * Position: top (60dp padding) or bottom (96dp padding) based on BannerPosition.
 */
@Composable
fun SurveyOverlayContent(manager: SurveyManager) {
    val shouldShowBanner by manager.shouldShowBanner.collectAsState()
    val activeSurveyState by manager.activeSurveyState.collectAsState()
    val isDark = resolveIsDark(sdkTheme = manager.theme)

    val surveyState = activeSurveyState ?: return
    val isHeader = surveyState.position == BannerPosition.HEADER

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = if (isHeader) Alignment.TopCenter else Alignment.BottomCenter
    ) {
        AnimatedVisibility(
            visible = shouldShowBanner,
            enter = slideInVertically(
                initialOffsetY = { if (isHeader) -it else it }
            ) + fadeIn(
                animationSpec = androidx.compose.animation.core.tween(250)
            ),
            exit = slideOutVertically(
                targetOffsetY = { if (isHeader) -it else it }
            ) + fadeOut(
                animationSpec = androidx.compose.animation.core.tween(250)
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = 16.dp,
                        vertical = if (isHeader) 60.dp else 96.dp
                    )
            ) {
                SurveyBannerView(
                    headline = surveyState.headline,
                    subtext = surveyState.subtext,
                    callToAction = surveyState.callToAction,
                    isDark = isDark,
                    onStartSurvey = { manager.openChat() },
                    onDismiss = { manager.dismissBanner() }
                )
            }
        }
    }
}
