package com.uxrate.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uxrate.sdk.models.ChatMessage
import com.uxrate.sdk.ui.theme.UXRateColors

/**
 * Chat bubble for user and assistant messages.
 * Maps to iOS ChatBubbleView.
 *
 * User: blue background, white text, right-aligned
 * Assistant: gray 15% background, primary text, left-aligned
 * Both: 18dp corner radius, 16dp/10dp padding, 60dp min spacer
 */
@Composable
fun ChatBubble(message: ChatMessage) {
    val isUser = message.role == ChatMessage.Role.USER

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (isUser) {
            Spacer(modifier = Modifier.widthIn(min = 60.dp))
        }

        Text(
            text = message.content,
            color = if (isUser) UXRateColors.userBubbleText else Color.Unspecified,
            fontSize = 16.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(
                    if (isUser) UXRateColors.userBubbleBackground
                    else UXRateColors.assistantBubbleBackground
                )
                .padding(horizontal = 16.dp, vertical = 10.dp)
        )

        if (!isUser) {
            Spacer(modifier = Modifier.widthIn(min = 60.dp))
        }
    }
}
