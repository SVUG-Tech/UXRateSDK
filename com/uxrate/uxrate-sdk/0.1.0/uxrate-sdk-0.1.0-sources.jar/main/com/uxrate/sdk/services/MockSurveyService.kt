package com.uxrate.sdk.services

import com.uxrate.sdk.models.*
import kotlinx.coroutines.delay
import java.util.Date

/**
 * Mock service for development and testing.
 * Maps to iOS MockSurveyService.
 * Returns hardcoded 2-survey config and 5-turn scripted chat.
 */
class MockSurveyService : SurveyService {

    private var userTurnCount = 0

    override suspend fun fetchConfiguration(apiKey: String): SDKConfig {
        return SDKConfig(
            surveys = listOf(
                SurveyConfig(
                    surveyId = "cmm9r5mri0001rvfm62fgu6lc",
                    name = "Home",
                    triggers = listOf(
                        TriggerRule(
                            type = "page_visit",
                            conditions = mapOf(
                                "pagePattern" to CodableValue.StringValue(".*Home.*|Product*|^Profile$")
                            )
                        )
                    ),
                    triggerLogic = "AND",
                    frequency = FrequencyConfig(
                        maxPerUser = 99,
                        cooldownDays = 0,
                        maxPerSession = 99
                    ),
                    appearance = AppearanceConfig(
                        headline = "Help us improve",
                        subtext = "Share your thoughts with us",
                        callToAction = "Get Started",
                        position = BannerPosition.NAVIGATION
                    )
                ),
                SurveyConfig(
                    surveyId = "cmm9r5mri0002rvfm72fgu7mc",
                    name = "Home Satisfaction",
                    triggers = listOf(
                        TriggerRule(
                            type = "page_visit",
                            conditions = mapOf(
                                "pagePattern" to CodableValue.StringValue(".*Home.*")
                            )
                        )
                    ),
                    triggerLogic = "AND",
                    frequency = FrequencyConfig(
                        maxPerUser = 99,
                        cooldownDays = 0,
                        maxPerSession = 99
                    ),
                    appearance = AppearanceConfig(
                        headline = "Quick feedback",
                        subtext = "Help us make things better",
                        callToAction = "Start Survey",
                        position = BannerPosition.HEADER
                    )
                )
            ),
            settings = GlobalSettings(maxSurveysPerDay = 99),
            cacheExpiresAt = Date(System.currentTimeMillis() + 3600_000)
        )
    }

    override suspend fun createSession(): List<String> {
        delay(300) // Simulate 0.3s network latency
        userTurnCount = 0
        return listOf(
            "Hi there! Thanks for taking the time to chat with us.",
            "We'd love to hear about your experience with the app. How has it been so far?"
        )
    }

    override suspend fun sendMessage(
        message: String,
        conversationHistory: List<ChatMessage>
    ): ChatReply {
        delay(400) // Simulate 0.4s network latency

        val responses = listOf(
            ChatReply(
                content = "Thanks for sharing! What are the main reasons you use this app?",
                isCompleted = false
            ),
            ChatReply(
                content = "Got it. Can you walk me through a typical session? What do you usually do first?",
                isCompleted = false
            ),
            ChatReply(
                content = "Have you encountered any difficulties or frustrations while using the app?",
                isCompleted = false
            ),
            ChatReply(
                content = "What features do you find most valuable, and is there anything you wish the app could do?",
                isCompleted = false
            ),
            ChatReply(
                content = "Thank you so much for your feedback! This has been really helpful. Have a great day!",
                isCompleted = true
            )
        )

        val index = userTurnCount.coerceAtMost(responses.size - 1)
        userTurnCount++
        return responses[index]
    }
}
