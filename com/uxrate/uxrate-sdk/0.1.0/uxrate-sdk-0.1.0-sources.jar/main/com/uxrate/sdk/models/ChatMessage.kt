package com.uxrate.sdk.models

import java.util.UUID

/**
 * Represents a single chat message in the survey conversation.
 * Maps to iOS ChatMessage struct.
 */
data class ChatMessage(
    val id: UUID = UUID.randomUUID(),
    val content: String,
    val role: Role,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Role {
        USER,
        ASSISTANT
    }
}

/**
 * Reply from the survey service.
 * Maps to iOS ChatReply struct.
 */
data class ChatReply(
    val content: String,
    val isCompleted: Boolean
)
