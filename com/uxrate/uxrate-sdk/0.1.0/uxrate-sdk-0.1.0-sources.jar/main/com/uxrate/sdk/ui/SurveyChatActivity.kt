package com.uxrate.sdk.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.uxrate.sdk.SurveyManager
import com.uxrate.sdk.UXRate
import com.uxrate.sdk.ui.theme.UXRateTheme

/**
 * Fullscreen Activity for the survey chat.
 * Maps to iOS chat sheet presentation (but as Activity, not BottomSheet).
 *
 * Launched by SurveyManager.openChat().
 * Uses the singleton SurveyManager from UXRate.
 */
class SurveyChatActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val manager = UXRate.surveyManager ?: run {
            finish()
            return
        }

        setContent {
            UXRateTheme(sdkTheme = manager.theme) {
                SurveyChatScreen(
                    manager = manager,
                    onClose = {
                        manager.onChatDismissed()
                        finish()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Handle swipe-back / system back dismiss
        UXRate.surveyManager?.onChatDismissed()
    }
}
